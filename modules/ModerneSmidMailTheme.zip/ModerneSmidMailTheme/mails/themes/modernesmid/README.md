# Moderne Smid Email Thema

Theme is build for usage with the modernesmid theme

This theme was generated based on MJML templates as they offer great responsiveness and ensure that
your templates will be readable in most mail viewers and mail web applications.

The source MJML templates and the tool allowing to compile/convert them as twig templates can be found at:

https://github.com/PrestaShop/mjml-theme-converter

You can use this repository as a base to create your own MJML templates.
