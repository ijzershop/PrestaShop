<?php

class Tools extends ToolsCore {
    public static function addonsRequest($request, $params = array())
    {
        return false;
    }
}


?>