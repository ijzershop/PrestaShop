<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_95f3ff3c125ae47e43b6afa408f86fc1'] = 'Invisible reCaptcha	';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_2ad696f635d1329ee717b3e409903c33'] = 'Añade un reCaptcha invisible al formulario de contacto de tu sitio web y a la página de registro de la cuenta	';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_a3635d4428d8cbcf6dccce8442e81505'] = 'necesita ser configurado';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_15cecc39d0a1bd801d2a60bdca3cbd59'] = 'La etiqueta HTML input type=\"submit\" name=\"submitMessage\" no se encuentra en \"contactform.tpl\"';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_bd16046f9e4bfea5a03cdff213c7f8ec'] = 'La plantilla \"contactform.tpl\" no se ha encontrado en su tema.';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_de7e39ae12eb7d5e08c84ff8739ee5fc'] = 'Por favor, rellene la clave pública del captcha';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_30c1139b1b654780ec1ef5c35323806d'] = 'Por favor, rellene la clave privada del captcha';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_2f90ba68e3387f62b0e22760c3bb9bd1'] = 'Configuración de reCaptcha invisible';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_77f682c46c4c98d39cfb703d3606f505'] = 'Para obtener sus propias claves públicas y privadas, haga clic en el siguiente enlace';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_059cff59cc5ead2a76d5d033c29a4754'] = 'Clave pública de reCaptcha';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_c25f66f2154ee54e4a57ad5c9897a264'] = 'Clave privada de reCaptcha';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_2aa54b500a188f2c2b83f47dfc00078c'] = 'Mostrar insignia reCaptcha';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_20e25a0442a6ae51330986dae8a81866'] = 'Habilitar reCaptcha en la página de registro';
$_MODULE['<{csoft_invisible_recaptcha_v2}prestashop>csoft_invisible_recaptcha_v2_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
