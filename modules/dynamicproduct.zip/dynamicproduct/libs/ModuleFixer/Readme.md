# Module Fixer
Allow easy troubleshooting of PrestaShop modules
