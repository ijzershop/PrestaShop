ALTER TABLE `__PREFIX_dropdown_option` ADD `secondary_value` varchar(100) NOT NULL;
ALTER TABLE `__PREFIX_thumbnails_option` ADD `secondary_value` varchar(100) NOT NULL;
ALTER TABLE `__PREFIX_radio_option` ADD `secondary_value` varchar(100) NOT NULL;
ALTER TABLE `__PREFIX_input_field` ADD `secondary_value` varchar(200) NOT NULL;