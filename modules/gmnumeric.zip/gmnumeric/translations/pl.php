<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gmnumeric}prestashop>gmnumeric_f20972eae641a1fcc374e73a6766c5e9'] = 'Numeryczna Referencja';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_75f866bcc1faa01f9ab0cdd976e5dfcd'] = 'Zmienia referencję zamówienia na numeryczną';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_ab9d6422bfc381bb5eb7d6834c24e7bd'] = 'Czy na pewno chcesz odinstalować ten niesamowity moduł?';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_c888438d14855d7d96a2724ee9c306bd'] = 'Zapisano ustawienia';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_f9a996eb9c56d5358ad6ecb9ead82915'] = 'Dodaj zera wiodące (do ID zamówienia)';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_4cd145e496691a962ceac9fb03e2532d'] = 'Format referencji';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_ac01c02278e2cb7a741bec1b46d5093f'] = 'Losowa liczba';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_d79cf3f429596f77db95c65074663a54'] = 'ID zamówienia';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_716de874a0d74f25c0aa8c444c3a7539'] = 'Prefiks';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_6d34a52bc1e19545e65e2a9050967f5b'] = 'maksymalnie 3 znaki';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_31fde7b05ac8952dacf4af8a704074ec'] = 'Podgląd';
$_MODULE['<{gmnumeric}prestashop>gmnumeric_eabf07766707348aa2cc833474cacb93'] = 'Wygenerowany indeks zamówienia:';
