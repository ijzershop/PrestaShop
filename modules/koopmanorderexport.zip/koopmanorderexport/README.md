# Koopman-Order-Export
Alle onderdelen van de koopmans order export module en label printer en pakbon aansturing



### Process

| Module Prestashop        | - genereerd transmission knoppen in bestellijst              |
| ------------------------ | ------------------------------------------------------------ |
| **Werkplaats computers** | -  Label printer koppeling                                   |
|                          | -  SumatraPDF koppeling voor uitlezen van labels en pakbonnen |
|                          | -  Pakbon printer koppeling                                  |
|                          | - koopman js script                                          |
|                          |                                                              |



Bestaat uit meerdere onderdelen.

**Prestashop module**

*De prestashop module maakt een koppeling tussen transmission en prestashop.* 

Bij het selecteren van een verzend/verpak wijze word er een label opgehaald bij transmission en opgeslagen in de "upload/koopman" map in de root van prestashop. Bij het aanmaken van een label word er ook een record in de verzendlijst van transmission aangemaakt. De bestelstatus word dan op "Klaar voor verzending" gezet.

Bij het maken van een bestelling word automatisch een pakbon aangemaakt en in dezelfde map "upload/koopman" geplaatst. De bestel status word dan op "pakbon geprint" gezet.

**Werkplaats computer**

De werkplaats computer gebruikt verschillende componenten voor het automatisch printen van pakbonnen en verzendlabels.

Onderdelen die gebruikt worden:

- koopman script (genaamd koopman.vbs)
- label map voor nieuwe labels
- oude labels map voor oude labels
- SumatraPdf 
- Label printer driver
- Pakbon printer driver



##### *koopmans script*

Het koopman script bevat een http request die iedere * seconden een aanvraag doet naar de opgegeven url om de labels en pakbonnen op te halen die klaar staan in de root van een prestashop installatie.

De parameters voor het script zijn:

##### *label map*

De label map word gebruikt om alle labels en pakbonnen die zijn opgehaald van de prestashop installatie te plaatsen. Deze blijven staan totdat ze zijn afgedrukt daarna worden ze in de "oude labels" map geplaatst.

##### *Sumatra Pdf*

Sumatra pdf word gebruikt voor het inlezen en uitlijnen van de labels en pakbonnen. Het pad naar het .exe bestand moet aangegeven worden in het koopman script. Als deze foutief is word er geen melding gedaan, er worden gewoon geen bonnen en labels geprint maar wel opgehaald.

##### *label printer*

De label printer print alleen de labels uit, deze staat als parameter ingesteld in het koopman.vbs script

##### *pakbon printer*

De pakbon printer print alleen de pakbonnen uit, deze worden direct na het ophalen van de prestashop installatie uitgeprint. De pakbon printer dient als standaard printer ingesteld te worden



#### Voorkomende errors



| Error                                                        | Oplossing                                                    |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| Pakbonnen worden geprint door label printer                  | Pakbon printer staat niet als standaard printer ingesteld    |
| Labels worden niet geprint en staan ook niet in de C:/koopman/label map | Http request word niet of gedeeltelijk uitgevoerd. Kijk eerst de prestashop rootmap "upload" na. |
| Labels worden niet geprint en staan ook niet in de C:/koopman/label en niet in de prestashop rootmap "upload" | Er zit een error in de module                                |
| Labels worden niet geprint en staan ook niet in de C:/koopman/label maar wel in de prestashop rootmap "upload" | Het koopman.vbs script word niet uitgevoerd. Kijk de parameters na: Klopt het pad naar de prestashop rootmap "upload" / klopt het pad naar het .exe bestand van sumatraPDF / word het script gestart doormiddel van de code "cscript koopman.vbs" in de terminal in te voeren? |
| Labels worden niet geprint en staan ook niet in de C:/koopman/label maar wel in de prestashop rootmap "upload" en kan het script wel uitvoeren doormiddel van de code "cscript koopman.vbs" | Plaats een snelkoppeling van het koopman.vbs script in de startup van windows |





