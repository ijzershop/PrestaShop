<?php
  
class ExportOrders {  
  var $configuration;
  var $labels_folder;
  var $orders_ok;

  var $status_verzonden = 4; //Verzonden status waar de orders na dagafsluiting op worden gezet

  var $soapoptions;

  public $redirect = true;
  public $output = "";
  
  public function __construct($configuration)
    {
        $this->configuration = $configuration;
        $this->orders_ok = array();

        $this->soapoptions = array(
        'stream_context' => stream_context_create(
            array(
              'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false
              )
            )
          )
        );

        $this->labels_folder = $_SERVER["DOCUMENT_ROOT"] . "/upload/" . $this->configuration["labels_folder"];

    }
    
    /**
   * Export orders
   **/
    public function export()
    {
      if(!empty($_GET["id_order"])){
        $orders = $this->_getOrders($this->configuration['select_status'], $this->configuration['select_carrier'], 1, $_GET["id_order"]);
      }else{
        $orders = $this->_getOrders($this->configuration['select_status'], $this->configuration['select_carrier']);
      }

      if (empty($orders))
       return false;
      



      /*
      old GLS code:
      $conversion = $this->_convertOrders($orders);

      $ok = $this->_saveAsCSV($conversion);
      */


      $this->_prepareLabelsFolder();

      if(true){

        if(!empty($_GET["id_order"])){

          if(isset($_GET["gewicht"])){
            $gewicht = (int)$_GET["gewicht"];
            if($gewicht==0)$gewicht=1;
          }

          if(isset($_GET["type"])){
            $type = $_GET["type"];
            if($type=='')$type='envelope';
          }

          $this->_processOrdersNew($orders, $type, $gewicht);  //met adreskeuze indien meer dan 1 koopman straat/plaats
        }else{
          $this->_processOrdersNew($orders);  //met adreskeuze indien meer dan 1 koopman straat/plaats
        }
      }else{
        $this->_processOrders($orders);
      }

      //Update orders when selected and uploaded
      if(isset($this->configuration['update_bool']) && $this->configuration['update_bool'] == 1 && is_numeric($this->configuration['update_status']) && count($this->orders_ok) > 0)
      {
        $this->_setNewStateForOrders($orders, $this->configuration['update_status']);
      }
    }
    
    private function _isDuracom(){
      return ($_SERVER["REMOTE_ADDR"] == "46.144.108.162");
    }

    /*
    Function to prepare output directory for labels, if it doesn't exist
    */
    private function _prepareLabelsFolder(){
      if(!is_dir($this->labels_folder)){
        @mkdir($this->labels_folder, 0755);
      }
      $code  = '<'.'?php' . PHP_EOL;
      $code .= 'foreach(glob("*.pdf") as $filename){' . PHP_EOL;
      $code .= '  header("Content-Description: File Transfer");' . PHP_EOL;
      $code .= '  header("Cache-Control: private");' . PHP_EOL;
      $code .= '  header("Content-Type: application/octet-stream");' . PHP_EOL;
      $code .= '  header("Content-Length: ".filesize($filename));' . PHP_EOL;
      $code .= '  header("Content-Disposition: attachment; filename=".$filename);' . PHP_EOL;
      $code .= '  header("Content-Transfer-Encoding: binary");' . PHP_EOL;
      $code .= '  readfile($filename);' . PHP_EOL;
      $code .= '  unlink($filename);' . PHP_EOL;
      $code .= '  break; //alleen de eerste' . PHP_EOL;
      $code .= '}' . PHP_EOL;
      $code .= '?'.'>';
      @file_put_contents($this->labels_folder . "/labels.php", $code);
    }

    public function dagafsluiting(){

      //file_put_contents($this->labels_folder . "/test.txt", "hiephoi");
      //return true;
      try{
        $client = new SoapClient($this->configuration['soap_url'], $this->soapoptions);
      } catch (Exception $e) {
        echo "error (new SoapClient) - ".$e->getMessage();
        return false;
      }

      $login = new stdClass();
      $login->username = $this->configuration['api_username'];
      $login->password = $this->configuration['api_password'];
      $login->depot = $this->configuration['koopman_depot'];
      $login->verlader = $this->configuration['koopman_verlader'];

      //verzendlijst ophalen en als pdf opslaan
      try{
        $verzendlijst = $client->getVerzendlijst($login);
      } catch (Exception $e) {
      }
      if($verzendlijst){
        file_put_contents($this->labels_folder . "/verzendlijst_" . time() . ".pdf", trim(base64_decode($verzendlijst)));
      }

      //meld zendingen voor met sendOpdrachten
      $client->sendOpdrachten($login);

      //orders op verzonden zetten..
      if(isset($this->configuration['update_bool']) && $this->configuration['update_bool'] == 1 && is_numeric($this->configuration['update_status']))
      {
        //orders selecteren die met eerdere acties op 'Ligt klaar voor verzenden' staan (of andere update_status)
        $orders = $this->_getOrders($this->configuration['update_status'], $this->configuration['select_carrier']);
        foreach($orders as $order){
          $this->orders_ok[] = $order["id_order"];
        }
        $this->_setNewStateForOrders($orders, $this->status_verzonden);
      }

    }

    /**
   * Get orders array for given state.
   * @param current order state
   * @param maximum number of records
   * @return array of orders
   **/
  private function _getOrders($state, $carrier, $max = 100, $id_order = null)
  {
    if (!is_numeric($state))
      return false;
      
    $sql = new DbQuery();
    $sql->select('*');
    $sql->from('orders', 'o');
    $sql->innerJoin('customer', 'c', 'c.id_customer = o.id_customer');
    $sql->innerJoin('address', 'a', 'a.id_address = o.id_address_delivery');
    $sql->innerJoin('country', 'co', 'co.id_country = a.id_country');
    if(isset($id_order)){ //als id is meegegeven dan maakt state en carrier niet meer uit
      $sql->where('o.id_order = ' . $id_order);
    }else{
      $sql->where('o.current_state = '.$state);
      //$sql->where('o.id_carrier = '.$carrier);
      //$sql->where('o.id_carrier NOT IN (SELECT id_carrier FROM `carrier` WHERE is_free = 1)'); //GDU 14-12-2015, knop tonen bij verzenden carrier (afhalen => isfree = 1)
    }
    $sql->limit($max);
    $sql->orderBy('id_order desc');
    return Db::getInstance()->executeS($sql);
  }

  /*
  * get first public message (from the client)
  * Toegevoegd om afleverinstructies van de klant door te geven aan koopman. GDU 28-8-2017
  */
  private function _getFirstClientMessage($id_order){
    if (!is_numeric($id_order))
      return false;

    $sql = new DbQuery();
    $sql->select('message');
    $sql->from('message', 'm');
    $sql->where('m.id_order = ' . $id_order);
    $sql->where('m.private = 0');
    $sql->limit(1);
    $sql->orderBy('id_message asc');
    return Db::getInstance()->executeS($sql);
  }

    
    /**
   * Change state of orders
   * @param orders array
   * @param new state
   * @return success
   **/
    private function _setNewStateForOrders($orders, $state)
    {
      //get order object for each order and change status
    foreach($orders as $order)
    {
      if(in_array($order['id_order'],$this->orders_ok)){
       $orderObject = new Order($order['id_order']);
       $orderObject->setCurrentState($state, 0);
      }
    }
    return true;
    }

    private function _processOrders($orders)
    {
      /*
      * (!) wordt niet gebruikt. Er is nu _processOrdersNew
      */

      if (empty($orders))
        return false;

      try{
        $client = new SoapClient($this->configuration['soap_url'], $this->soapoptions);
      } catch (Exception $e) {
        //echo "error (new SoapClient) - ".$e->getMessage();
        return false;
      }

      $login = new stdClass();
      $login->username = $this->configuration['api_username'];
      $login->password = $this->configuration['api_password'];
      $login->depot = $this->configuration['koopman_depot'];
      $login->verlader = $this->configuration['koopman_verlader'];

      foreach($orders as $row){

        $opdracht = new stdClass();
        $opdracht->type = "T"; // T = Stukgoed Levering
        $opdracht->nrorder = $row["reference"];
        $opdracht->afzender = $this->configuration['koopman_afzender'];
        $opdracht->geanaam = $row['firstname']." ".$row['lastname'];
        $opdracht->geanaam2 = $row['company'];
        $adres = $this->_splitAddress($row['address1']);
        $opdracht->geastraat = $row["address1"];
        $opdracht->geahuisnr = $row["house_number"];
        $opdracht->geapostcode = $row['postcode'];
        $opdracht->geaplaats = $row['city'];
        $opdracht->gealand = $row['iso_code'];
        $opdracht->geatelefoon = $row['phone'];
        $opdracht->geaemail = $row['email'];



        if($opdracht->gealand == "NL"){ // haal straat + plaats op bij koopman voor NL
          try{
            $adres = $client->getAdresNL_2($login, $row['postcode']);
          } catch (Exception $e) {
          }
          if(is_array($adres) && count($adres) > 0){
            $opdracht->geastraat = $adres[0]->straat;
            $opdracht->geaplaats = $adres[0]->plaats;
          }
        }

        if(isset($_GET["zaterdag"]) && (int)$_GET["zaterdag"] == 1 && $opdracht->gealand == "NL"){
          $opdracht->zaterdag = 1;
          if(empty($opdracht->geatelefoon)){
            $opdracht->geatelefoon = "1234567890"; //zaterdaglevering = telefoon verplicht
          }
        }

        $regel = new stdClass();
        $regel->nrcollo = 1;
        $gewicht = 1;
        if(isset($_GET["gewicht"])){
          $gewicht = (int)$_GET["gewicht"];
          if($gewicht==0)$gewicht=1;
        }
        $regel->vrzenh = "COL";
        /*
        if($gewicht==14){
          $regel->vrzenh = "collo1";
        }
        if($gewicht==30){
          $regel->vrzenh = "collo2";
        }
        */
        $regel->gewicht = $gewicht;
        if($gewicht == 1){
          $regel->lengte = 30;
          $regel->hoogte = 20;
          $regel->breedte = 50;
        }else{
          $regel->lengte = 160;
          $regel->hoogte = 20;
          $regel->breedte = 20;
        }

        $opdracht->aRegel[1] = $regel;

        $transport = false;
        try{
          $transport = $client->addOpdracht($login, $opdracht);
        } catch (Exception $e) {
          //die("error - ".$e->getMessage());
          session_start();
          $_SESSION["koopmanError"] = $e->getMessage();
        }

        if($transport){
          $zendingnr = $transport->zendingnr;
          $zendingnr = "T" . substr($zendingnr,1); //T98
          $labels = $transport->labels;

          if(file_put_contents($this->labels_folder . "/" . $zendingnr . ".pdf", trim(base64_decode($labels)))){
            $this->orders_ok[] = $row["id_order"];
          }
        }

      }

    }

    private function _processOrdersNew($orders, $type, $gewicht)
    {
      if (empty($orders))
        return false;

      try{
        $client = new SoapClient($this->configuration['soap_url'], $this->soapoptions);
      } catch (Exception $e) {
        //echo "error (new SoapClient) - ".$e->getMessage();
        return false;
      }



      $login = new stdClass();
      $login->username = $this->configuration['api_username'];
      $login->password = $this->configuration['api_password'];
      $login->depot = $this->configuration['koopman_depot'];
      $login->verlader = $this->configuration['koopman_verlader'];

      foreach($orders as $row){

        $opdracht = new stdClass();
        $opdracht->type = "T"; // T = Stukgoed Levering
        $opdracht->nrorder = $row["reference"];
        $opdracht->afzender = $this->configuration['koopman_afzender'];
        $opdracht->geanaam = $row['firstname']." ".$row['lastname'];
        $opdracht->geanaam2 = $row['company'];
        $adres = $this->_splitAddress($row['address1']);
        $opdracht->geastraat = $row["address1"];
        $opdracht->geahuisnr = $row["house_number"];
        $opdracht->geapostcode = $row['postcode'];
        $opdracht->geaplaats = $row['city'];
        $opdracht->gealand = $row['iso_code'];
        $opdracht->geatelefoon = $row['phone'];
        $opdracht->geaemail = $row['email'];


        $msg = $this->_getFirstClientMessage($row["id_order"]);

        if(!empty($msg)){
          $opdracht->instructie = $msg[0]["message"];
        }

        if($opdracht->gealand == "NL"){ // haal straat + plaats op bij koopman voor NL
          try{
            $adressen = $client->getAdresNL_2($login, $row['postcode']);
          } catch (Exception $e) {
          }
          if(is_array($adressen)){

            $klant_straat = $opdracht->geastraat.' '.$opdracht->geahuisnr;
            $klant_plaats = $opdracht->geaplaats;

            if((count($adressen) > 1) || (trim(strtolower($opdracht->geastraat)) != trim(strtolower($adressen[0]->straat)))){
              if(isset($_GET["adres" . $row["id_order"]])){
                $idx = (int)$_GET["adres" . $row["id_order"]];
                $opdracht->geastraat = $adressen[$idx]->straat;
                $opdracht->geaplaats = $adressen[$idx]->plaats;
              }else{

             

                $opdracht->geaplaats = "";
                $this->redirect = false;

                $this->output .= '<br/><form method="get" action="index.php">' . PHP_EOL;

                foreach ($_GET as $key => $value) {
                    $this->output .= "<input type='hidden' name='$key' value='$value'/>" . PHP_EOL;
                }

                $this->output .= '<table width="400" align="center" border="0" cellpadding="3">' . PHP_EOL;

                $this->output .= "<tr><td>" . "<b>Ingevuld door klant:</b></td></tr><tr><td>" . $klant_straat . ", " . $opdracht->geapostcode . " " . $klant_plaats . "</td></tr>" . PHP_EOL;

                $this->output .= "<tr><td><br/>" . "<b>Kies een straat/plaats:</b></td></tr>" . PHP_EOL;
                foreach($adressen as $ix=>$adres){
                  $this->output .= '<tr><td><input type="radio" name="adres' . $row["id_order"] . '" id="adres' . $ix . '" value="' . $ix . '"' . (($ix==0) ? ' checked="checked"' : '') . '>&nbsp;<label for="adres'.$ix.'">' . $adres->straat . ', ' . $adres->plaats . '</label></td></tr>' . PHP_EOL;
                }
                $this->output .= '<tr><td><br/><input type="submit" value="OK" style="width:200px;height:25px;"></td></tr>' . PHP_EOL;

                $this->output .= '</table></form>' . PHP_EOL;
              }
            }else{
              $opdracht->geastraat = $adressen[0]->straat;
              $opdracht->geaplaats = $adressen[0]->plaats;
            }
          }
        }

        if(isset($_GET["zaterdag"]) && (int)$_GET["zaterdag"] == 1 && $opdracht->gealand == "NL"){
          $opdracht->zaterdag = 1;
          if(empty($opdracht->geatelefoon)){
            $opdracht->geatelefoon = "1234567890"; //zaterdaglevering = telefoon verplicht
          }
        }



        if(!empty($opdracht->geaplaats)){

          $regel = new stdClass();
          $regel->nrcollo = 1;
          // $gewicht = 1;

            /*
            *  Gewijzigd door JB Stoker - Moderne Smid
            *  Pakket maten en soorten aangepast en type optie toegevoegd
            *  -Envelop : (50 x 30 x 1=1Kg) / value = envelope
            *  -Plaat : (50 x 30 x 1=15Kg) / value = plaat
            *  -1 Meter : (50 x 30 x 1=15Kg) / value = 1-meter
            *  -2 Meter < 15 : (50 x 30 x 1= 14Kg) / value = 2-meter-smaller
            *  -2 Meter > 15 : (50 x 30 x 1= 30Kg) / value = 2-meter-larger
            *  
            */

          // if(isset($_GET["gewicht"])){
          //   $gewicht = (int)$_GET["gewicht"];
          //   if($gewicht==0)$gewicht=1;
          // }

          // if(isset($_GET["type"])){
          //   $type = $_GET["type"];
          //   if($type=='')$type='envelope';
          // }


          $regel->vrzenh = "COL";
          

          /*
          if($gewicht==14){
            $regel->vrzenh = "collo1";
          }
          if($gewicht==30){
            $regel->vrzenh = "collo2";
          }
          */
          $regel->gewicht = $gewicht;

          switch ($type) {
            case 'envelope':
                $regel->lengte = 50;
                $regel->breedte = 30;
                $regel->hoogte = 1;
              break;
            case 'plaat':
                $regel->lengte = 100;
                $regel->breedte = 50;
                $regel->hoogte = 1;
              break;
            case '1-meter':
                $regel->lengte = 100;
                $regel->breedte = 20;
                $regel->hoogte = 20;
              break;
            case '2-meter-smaller':
                $regel->lengte = 199;
                $regel->breedte = 15;
                $regel->hoogte = 15;
              break;
            case '2-meter-larger':
                $regel->lengte = 199;
                $regel->breedte = 15;
                $regel->hoogte = 15;
              break;
            default://envelope sizes
                $regel->lengte = 50;
                $regel->breedte = 30;
                $regel->hoogte = 1;
              break;
          }

          // if($gewicht == 1){
          //   $regel->lengte = 30;
          //   $regel->hoogte = 20;
          //   $regel->breedte = 50;
          // }else{
          //   $regel->lengte = 160;
          //   $regel->hoogte = 20;
          //   $regel->breedte = 20;
          // }

          $opdracht->aRegel[1] = $regel;

          $transport = false;
          try{
            $transport = $client->addOpdracht($login, $opdracht);
          } catch (Exception $e) {
            //die("error - ".$e->getMessage());
            session_start();
            $_SESSION["koopmanError"] = $e->getMessage();
          }

          if($transport){
            $zendingnr = $transport->zendingnr;
            $zendingnr = "T" . substr($zendingnr,1); //T98
            $labels = $transport->labels;

            if(file_put_contents($this->labels_folder . "/" . $zendingnr . ".pdf", trim(base64_decode($labels)))){
              $this->orders_ok[] = $row["id_order"];
            }
          }

        }

      }

    }

    /*
    Helper functie om huisnummer en straat te scheiden
    */
    function _splitAddress($adres){
      $arr_adres = explode(" ",$adres);
      $huisnummer = false;
      $arr_straat = array();
      $arr_huisnr = array();
      $i=0;
      foreach($arr_adres as $deel){
        if($i>0 && is_numeric(substr($deel,0,1)))$huisnummer = true; //vanaf eerste deel welke met getal begint is het huisnummer (behalve allereerste element)
        if($huisnummer){
          $arr_huisnr[] = $deel;
        }else{
          $arr_straat[] = $deel;
        }
        $i++;
      }
      return array("straat" => implode(" ", $arr_straat), "huisnummer" => implode(" ", $arr_huisnr));
    }
    
    /**
   * Convert retreived orders into gls csv format
   * @param orders array
   * @return converted array
   **/
   /*
    private function _convertOrders($orders)
    {
      if (empty($orders))
        return array();
      $csv = array();
    
    //Create header
    $csv['0']['naam'] = "NAAM GEADRESSEERDE";
    $csv['0']['naam2'] = "NAAM 2";
    $csv['0']['straatenhuisnummer'] = "STRAATENHUISNUMMER";
    $csv['0']['postcode'] = "POSTCODE";
    $csv['0']['plaats'] = "PLAATS";
    $csv['0']['land'] = "LAND";
    
    $csv['0']['referentie'] = "REFERENTIE";
    $csv['0']['aantal'] = "AANTAL"; 
    $csv['0']['gewicht'] = "GEWICHT";
    $csv['0']['verpakking'] = "VERPAKKING";
    $csv['0']['verladernummer'] =  "VERLADERNUMMER";
    $csv['0']['express'] =  "EXPRESS";
    
    $csv['0']['telefoongeeadresseerde'] = "TELEFOONGEADRESSEERDE";
    $csv['0']['sms'] = "SMS";
    $csv['0']['emailadres'] = "EMAILADRES";
    $csv['0']['typeadres'] = "TYPEADRES";
    //Fill array
    foreach($orders as $row)
    {
      $csv[$row['id_order']]['naam'] = $row['firstname']." ".$row['lastname'];
      $csv[$row['id_order']]['naam2'] = $row['company'];
      $csv[$row['id_order']]['straatenhuisnummer'] = $row['address1'];
      $csv[$row['id_order']]['postcode'] = $row['postcode'];
      $csv[$row['id_order']]['plaats'] = $row['city'];
      $csv[$row['id_order']]['land'] = $row['iso_code'];
      
      $csv[$row['id_order']]['referentie'] = $row['id_order'];
      $csv[$row['id_order']]['aantal'] = "1";
      $csv[$row['id_order']]['gewicht'] = "1";
      $csv[$row['id_order']]['verpakking'] = "pco";
      $csv[$row['id_order']]['verladernummer'] = "89010051";
      $csv[$row['id_order']]['express'] =  "";
      
      $csv[$row['id_order']]['telefoongeeadresseerde'] = $row['phone'];
      $csv[$row['id_order']]['sms'] = "";
      $csv[$row['id_order']]['emailadres'] = $row['email'];
      $csv[$row['id_order']]['typeadres'] = "P";  
    }
    return $csv;
    }
    */
    
    /**
   * Save as csv file on configurated ftp server
   **/
   /*
    private function _saveAsCSV($data)
    {
      //Create temp file
    $fp = fopen('php://temp', 'r+');
    //Put csv info into temp file
    foreach ($data as $fields) {
        fputcsv($fp, $fields, ';');
    }
    //Upload temp file to ftp
    rewind($fp);
    $upload = $this->_uploadToFTP($fp, $this->configuration['ftp_dir'], $this->configuration['ftp_host'], $this->configuration['ftp_user'], $this->configuration['ftp_password'], $this->configuration['ftp_port']);
    //Close temp file
    fclose($fp);
    
    return $upload;
    }
    */
    
    /**
   * Connect to ftp server and return handle
   * @var string url of ftp server
   * @var string username
   * @var string password
   * @var int portnumber, default: 21
   * @return ftp handle
   **/

   /*
  private function _uploadToFTP($file_pointer, $upload_dir = '/', $url, $username = null, $password = null, $port = 21 )
  { 
    $succes = false;
    $ftp_connection = ftp_connect($url, $port);
    if (ftp_login($ftp_connection, $username, $password))
    {
      //Login succesfull try uploading file
      $file_name = "GlsExport".time().".csv";
      
      ftp_chdir($ftp_connection, $upload_dir);
      
      $succes = ftp_fput($ftp_connection, $file_name, $file_pointer, FTP_ASCII);
    }
    ftp_close($ftp_connection);
    
    return $succes;
  }
  */
    
}