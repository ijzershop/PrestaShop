<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if (!defined('_PS_VERSION_'))
	exit;

require_once(_PS_MODULE_DIR_.'koopmanorderexport/classes/exportOrders.php');


class koopmanDagafsluitingAdminController extends ModuleAdminController {

	public function __construct()
    {
        $this->module = 'koopmanorderexport';
	    $this->lang = true;
	    $this->context = Context::getContext();
	    $this->bootstrap = true;

		parent::__construct();

    }


	/**
	 *
	 **/
   public function display()
    {
	    //Retreive module configuration
    	$configuration = $this->_getConfiguration();

	    $export = new ExportOrders($configuration);
	    $export->dagafsluiting();

		//Redirect to orders page
		$token = Tools::getAdminTOkenLite('AdminOrders');
		Tools::redirectAdmin("index.php?controller=AdminOrders&token=".$token);
    }

    public function initContent()
    {

	}


	/**
	 * Retreive module configuration
	 **/
	private function _getConfiguration()
	{

		return unserialize(Configuration::get("koopmanOrderExport"));
	}

}