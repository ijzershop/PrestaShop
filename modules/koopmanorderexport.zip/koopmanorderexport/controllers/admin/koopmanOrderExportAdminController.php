<?php
if (!defined('_PS_VERSION_'))
	exit; 

require_once(_PS_MODULE_DIR_.'koopmanorderexport/classes/exportOrders.php');


class koopmanOrderExportAdminController extends ModuleAdminController {
	
	public function __construct()
    {
        $this->module = 'koopmanorderexport';
	    $this->lang = true;
	    $this->context = Context::getContext();
	    $this->bootstrap = true;

		parent::__construct();
		
    }
	
	
	/**
	 *
	 **/
   public function display()
    {	
	    //Retreive module configuration
    	$configuration = $this->_getConfiguration();
	    
	    $export = new ExportOrders($configuration);
	    $export->export();
	    
		//Redirect to orders page
      if($export->redirect){

        $token = Tools::getAdminTokenLite('AdminOrders');

        Tools::redirectAdmin("index.php?controller=AdminOrders&token=".$token);
      }else{
      ?>
      <html>
        <head>
          <title></title>
          <style type="text/css">
            * {
              font-family: Arial;
            }
            label{
              cursor:pointer;
            }
          </style>
        </head>
        <body>
          <?php
            echo $export->output;
          ?>
        </body>
      </html>
      <?php
      }
    }
    
    public function initContent() 
    {
            
	}
	
  private function _isDuracom(){
    return ($_SERVER["REMOTE_ADDR"] == "46.144.108.162");
  }
	
	/**
	 * Retreive module configuration
	 **/
	private function _getConfiguration()
	{
		
		return unserialize(Configuration::get("koopmanOrderExport"));
	}
	
}