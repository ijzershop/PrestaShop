<?php 
if (!defined('_PS_VERSION_')) 	
	exit; 

class koopmanOrderExport extends Module {
	
	var $configuration = array();
  	var $status_vertraagd = 18;

	static private $currentIndex;
	
	public function __construct() { 		

		$this->name = 'koopmanorderexport';
		$this->tab = 'others'; 	    
		$this->version = '1.0.1'; 	    
		$this->author = 'Duracom internetdiensten';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
		$this->bootstrap = true;
		$this->context = Context::getContext();
		parent::__construct();
		
		$this->displayName = $this->l('Koopman TransMission Order Export');
		$this->description = $this->l('Export orders to Koopman TransMission API. Labels will be saved to specified folder in upload folder.');
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
		
		if (!Configuration::get($this->name))
			$this->warning = $this->l('No name provided');
			
		$this->_getConfiguration();
		
		
	}
	
	public function install() {
		$this->_addMenuTab();
		if (!parent::install() || !$this->registerHook('displayAdminOrder') 
			|| !$this->registerHook('displayAdminEndContent')  
			|| !$this->registerHook('displayAdminAfterHeader')
			|| !$this->registerHook('displayBackOfficeTop')
			|| !$this->registerHook('actionAdminControllerSetMedia'))
			return false;
		return true;
	} 
	
	private function _addMenuTab()
	{
		$adminMenuItem = new Tab();
		$adminMenuItem->name[$this->context->language->id] = $this->l('Koopman label(s) printen');
		$adminMenuItem->class_name = "koopmanOrderExportAdmin";
		$adminMenuItem->module = $this->name;
		$adminMenuItem->id_parent = Tab::getIdFromClassName('AdminParentOrders');
		$adminMenuItem->add();

		$adminMenuItem = new Tab();
		$adminMenuItem->name[$this->context->language->id] = $this->l('Koopman dagafsluiting');
		$adminMenuItem->class_name = "koopmanDagafsluitingAdmin";
		$adminMenuItem->module = $this->name;
		$adminMenuItem->id_parent = Tab::getIdFromClassName('AdminParentOrders');
		$adminMenuItem->add();

	}
		
	public function uninstall()
	{
		if (!parent::uninstall())
			return false;
		return true;
	}
	/**
	 * Configuration page
	 **/
	public function getContent()
	{
		$output = null;
 
	    if (Tools::isSubmit('submit'.$this->name))
	    {		  
	            $this->configuration['select_status'] = Tools::getValue('select_status');
	            $this->configuration['select_carrier'] = Tools::getValue('select_carrier');
	            $this->configuration['update_bool'] = Tools::getValue('update_bool');
	            $this->configuration['update_status'] = Tools::getValue('update_status');
	            $this->configuration['soap_url'] = Tools::getValue('soap_url');
	            $this->configuration['api_username'] = Tools::getValue('api_username');
	            $this->configuration['api_password'] = Tools::getValue('api_password');
              	$this->configuration['koopman_afzender'] = Tools::getValue('koopman_afzender');
	            $this->configuration['koopman_depot'] = Tools::getValue('koopman_depot');
	            $this->configuration['koopman_verlader'] = Tools::getValue('koopman_verlader');
	            $this->configuration['labels_folder'] = Tools::getValue('labels_folder');
	            $this->_saveConfiguration();
	            
	            //Configuration::updateValue("koopmanOrderExport", $my_module_name);
	            $output .= $this->displayConfirmation($this->l('Settings updated'));
	        //}
	    }
	    
	    return $output.$this->displayForm();
	}
	
	public function displayForm()
	{
		//Get values for selectboxes
		$id_lang = (int)$this->context->language->id;
		$orderstatus = OrderStateCore::getOrderStates($id_lang);
		$carriers = CarrierCore::getCarriers($id_lang);
		
	    // Get default Language
	    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
	     
	    // Init Fields form array
	    $fields_form[0]['form'] = array(
	        'legend' => array(
	            'title' => $this->l('Settings'),
	        ),
	        'input' => array(
	            array(     
					'type' => 'select',                              
					'label' => $this->l('Select status condition'),
					'desc' => $this->l('Choose the status of the orders to export.'), 
					'name' => 'select_status',   
					'required' => true,           
					'options' => array(
						'query' => $orderstatus, 
						'id' => 'id_order_state',  
						'name' => 'name'
					)
				),
				array(
					'type' => 'select',                              
					'label' => $this->l('Select carrier condition'),
					'desc' => $this->l('Choose the carrier of the orders to export.'), 
					'name' => 'select_carrier',   
					'required' => true,           
					'options' => array(
						'query' => $carriers, 
						'id' => 'id_carrier',  
						'name' => 'name'
					)
				),
				array(
					'type'    => 'radio',                         
					'label'   => $this->l('Change order status'),                
					'desc'    => $this->l(''),        
					'name'    => 'update_bool',     
					'is_bool' => true,
					'values'    => array(
					    array(
					    	'id'    => 'active_on',
							'value' => 1,                                     
							'label' => $this->l('Enabled')                   
					    ),
					    array(
					    	'id'    => 'active_off',
							'value' => 0,
							'label' => $this->l('Disabled')
					    )
					),                     
				),
				array(
					'type' => 'select',                              
					'label' => $this->l('Change order-status into'),
					'desc' => $this->l('Choose the status to convert orders into'), 
					'name' => 'update_status',   
					'required' => true,           
					'options' => array(
						'query' => $orderstatus, 
						'id' => 'id_order_state',  
						'name' => 'name'
					)
				),
				array(
	                'type' => 'text',
	                'label' => $this->l('SOAP Url'),
	                'name' => 'soap_url',
	                'size' => 20,
	                'required' => true
	            ),
				array(
	                'type' => 'text',
	                'label' => $this->l('API Username'),
	                'name' => 'api_username',
	                'size' => 20,
	                'required' => true
	            ),
				array(
	                'type' => 'text',
	                'label' => $this->l('API Password'),
	                'name' => 'api_password',
	                'size' => 20,
	                'required' => true
	            ),
				array(
	                'type' => 'text',
	                'label' => $this->l('Koopman Afzender'),
	                'name' => 'koopman_afzender',
	                'size' => 20,
	                'required' => true
	            ),
				array(
	                'type' => 'text',
	                'label' => $this->l('Koopman Depot'),
	                'name' => 'koopman_depot',
	                'size' => 20,
	                'required' => true
	            ),
				array(
	                'type' => 'text',
	                'label' => $this->l('Koopman Verlader'),
	                'name' => 'koopman_verlader',
	                'size' => 20,
	                'required' => true
	            ),
				array(
	                'type' => 'text',
	                'label' => $this->l('Labels folder (/upload/...)'),
	                'name' => 'labels_folder',
	                'size' => 20,
	                'required' => true
	            )

	        ),
			'submit' => array(
	            'title' => $this->l('Save'),
	            'class' => 'button'
	        )
	    );
	     
	    $helper = new HelperForm();
	     
	    // Module, t    oken and currentIndex
	    $helper->module = $this;
	    $helper->name_controller = $this->name;
	    $helper->token = Tools::getAdminTokenLite('AdminModules');
	    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
	     
	    // Language
	    $helper->default_form_language = $default_lang;
	    $helper->allow_employee_form_lang = $default_lang;
	     
	    // Title and toolbar
	    $helper->title = $this->displayName;
	    $helper->show_toolbar = true;        // false -> remove toolbar
	    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
	    $helper->submit_action = 'submit'.$this->name;
	    $helper->toolbar_btn = array(
	        'save' =>
	        array(
	            'desc' => $this->l('Save'),
	            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
	            '&token='.Tools::getAdminTokenLite('AdminModules'),
	        ),
	        'back' => array(
	            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
	            'desc' => $this->l('Back to list')
	        )
	    );
	     
	    // Load current value
	    $helper->fields_value['select_status'] = (isset($this->configuration['select_status']))? $this->configuration['select_status']: '';
	    $helper->fields_value['select_carrier'] = (isset($this->configuration['select_carrier']))? $this->configuration['select_carrier']: '';
	    $helper->fields_value['update_bool'] = (isset($this->configuration['update_bool']))? $this->configuration['update_bool']: '0';
	    $helper->fields_value['update_status'] = (isset($this->configuration['update_status']))? $this->configuration['update_status']: '';
	    $helper->fields_value['soap_url'] = (isset($this->configuration['soap_url']))? $this->configuration['soap_url']: '';
	    $helper->fields_value['api_username'] = (isset($this->configuration['api_username']))? $this->configuration['api_username']: '';
	    $helper->fields_value['api_password'] = (isset($this->configuration['api_password']))? $this->configuration['api_password']: '';
	    $helper->fields_value['koopman_afzender'] = (isset($this->configuration['koopman_afzender']))? $this->configuration['koopman_afzender']: '';
	    $helper->fields_value['koopman_depot'] = (isset($this->configuration['koopman_depot']))? $this->configuration['koopman_depot']: '';
	    $helper->fields_value['koopman_verlader'] = (isset($this->configuration['koopman_verlader']))? $this->configuration['koopman_verlader']: '';
	    $helper->fields_value['labels_folder'] = (isset($this->configuration['labels_folder']))? $this->configuration['labels_folder']: 'koopman';

	     
	    return $helper->generateForm($fields_form);
	}
	
	private function _getOrders($state, $carrier, $max = 300, $id_order = null)
	{
		if (!is_numeric($state))
			return false;

		$sql = new DbQuery();
		$sql->select('*');
		$sql->from('orders', 'o');
		$sql->innerJoin('customer', 'c', 'c.id_customer = o.id_customer');
		$sql->innerJoin('address', 'a', 'a.id_address = o.id_address_delivery');
		$sql->innerJoin('country', 'co', 'co.id_country = a.id_country');
    if(isset($id_order)){ //als id is meegegeven dan maakt state en carrier niet meer uit
      $sql->where('o.id_order = ' . $id_order);
    }else{
  		$sql->where('o.current_state = '.$state);
  		$sql->where('o.id_carrier = '.$carrier);
    }
		$sql->limit($max);
		$sql->orderBy('id_order desc');
		return Db::getInstance()->executeS($sql);
	}
	
	/**
	 * Load CSS + JS files in header
	 **/
  public function hookDisplayAdminEndContent(){
    $gls_orders = $this->_getOrders($this->configuration['select_status'], $this->configuration['select_carrier']);
    //ook 'Ligt klaar voor..' orders meenemen ivm. evt. extra stickers
    $ligt_klaar_orders = $this->_getOrders($this->configuration['update_status'], $this->configuration['select_carrier']);
    //10-8-2018 GDU, ook vertraagde orders meenemen
    $vertraagde_orders = $this->_getOrders($this->status_vertraagd, $this->configuration['select_carrier']);
    $orders = array_merge($gls_orders, $ligt_klaar_orders, $vertraagde_orders);
    if(!empty($orders)){
      $order_ids = array();
      $gls_order_ids = array();
      foreach($orders as $order){
        $order_ids[] = $order["id_order"];
      }
      foreach($gls_orders as $gls_order){
        $gls_order_ids[] = $gls_order["id_order"];
      }
      $script = "<script>" . PHP_EOL . "var koopman_order_ids = [" . implode(",",$order_ids) . "];" . PHP_EOL . "var gls_order_ids = [" . implode(",",$gls_order_ids) . "];" . PHP_EOL . file_get_contents($_SERVER["DOCUMENT_ROOT"].'/modules/koopmanorderexport/views/js/koopman.js') . PHP_EOL;
      if (session_status() == PHP_SESSION_NONE) {
		    session_start();
		}
      if(isset($_SESSION["koopmanError"])){
        $script .= "alert('Koopman fout: " . str_replace("'","\'",$_SESSION["koopmanError"]) . "');" . PHP_EOL;
        unset($_SESSION["koopmanError"]);
      }
      $script .= "</script>";
      return $script;
    }
  }	
	
	public function initToolbar() {
		$this->toolbar_btn['help'] = array(
		'desc' => $this->l('Help'),
		'js' => 'window.open(\''.AdminController::$currentIndex.'
		&add'.$this->table.'&token='.Tools::getAdminTokenLite('AdminModules').'\',\''.'popupwindow \''.',
		 \''.'width=500\',\'height=500\',\'scrollbars\',\'resizable\');',
		);
	}
	
	  private function _isDuracom(){
	    return $_SERVER["REMOTE_ADDR"] = "46.44.132.142";
	  }
	
	private function _getConfiguration()
	{
		
		$this->configuration = unserialize(Configuration::get("koopmanOrderExport"));
	}
	
	private function _saveConfiguration()
	{
		
		if (!empty($this->configuration))
			Configuration::updateValue("koopmanOrderExport", serialize($this->configuration));
	}	
		
}