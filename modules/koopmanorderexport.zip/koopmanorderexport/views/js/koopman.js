$(document).ready(function(){

  if($('#subtab-koopmanOrderExportAdmin a').length){

    $('#subtab-koopmanOrderExportAdmin a').hide();
    if($('#subtab-glsOrderExportAdmin a').length)$('#subtab-glsOrderExportAdmin a').hide();

    $('#subtab-koopmanOrderExportAdmin a').click(function(e){
      if(!confirm('Weet u het zeker? Alle Koopman labels zullen worden afgedrukt.')){
        e.preventDefault();
      }
    });

    $('body.adminorders table td span.label.color_field').each(function(ix,el){
      var $el = $(el);
      var $td = $el.closest('td');
      var status = $el.text().trim();
      var id_order = parseInt($td.attr('onclick').split('id_order=')[1].split('&')[0]);
      //koopman button
      console.log(['all',id_order, koopman_order_ids]);
      if($.inArray(id_order, koopman_order_ids) > -1){
        var link = $('#subtab-koopmanOrderExportAdmin a').attr('href');
        link += '&id_order=' + id_order;
        $td.attr('nowrap','nowrap');
        // $td.append('<a class="btn btn-default koopman" href="' + link + '" title="Koopman label afdrukken" style="padding:1;margin-right:3px;position:relative;"><img style="width:18px;height:18px;" src="/modules/koopmanOrderExport/logo.png" /><select style="position:absolute;left:0;top:0;width:35px;height:31px;opacity:0;cursor:pointer;"><option value="-1"></option><option value="1">1kg</option><option value="3">3kg</option><option value="14">3-14kg</option><option value="30">15-30kg</option></select></a>');
      console.log(['filtered',id_order, koopman_order_ids]);

        /*
        *  Gewijzigd door JB Stoker - Moderne Smid
        *  Pakket maten en soorten aangepast
        *  1 -Envelop : (50 x 30 x 1=1Kg) / value = envelope
        *  2 -Plaat : (50 x 30 x 1=15Kg) / value = plaat
        *  3 -1 Meter : (50 x 30 x 1=15Kg) / value = 1-meter
        *  4 -2 Meter < 15 : (50 x 30 x 1= 14Kg) / value = 2-meter-smaller
        *  5 -2 Meter > 15 : (50 x 30 x 1= 30Kg) / value = 2-meter-larger
        *  
        */
        $td.append('<a class="btn btn-default koopman" href="' + link + '" title="Koopman label afdrukken" style="padding:1;margin-right:3px;position:relative;"><img style="width:18px;height:18px;" src="/modules/koopmanOrderExport/logo.png"/><select style="position:absolute;left:0;top:0;width:35px;height:31px;opacity:0;cursor:pointer;"> <option value="-1"></option> <option value="envelope">Envelop  </option> <option value="plaat">Plaat  </option> <option value="1-meter">1 meter  </option> <option value="2-meter-smaller">2 meter <15Kg  </option> <option value="2-meter-larger">2 meter >15Kg  </option></select></a>');
      }
      //gls button
      /*
      - GDU 4-5-2017 - uitgeschakeld op verzoek van Tako

      if($('#subtab-glsOrderExportAdmin a').length){
        if($.inArray(id_order, gls_order_ids) > -1){
          var link = $('#subtab-glsOrderExportAdmin a').attr('href');
          link += '&id_order=' + id_order;
          $td.attr('nowrap','nowrap');
          $td.append('<a class="btn btn-default gls" href="' + link + '" title="GLS label afdrukken" style="padding:1;"><img style="width:18px;height:18px;" src="/modules/glsOrderExport/gls.png" /></a>');
        }
      }
      */
    });

    $('a.btn.gls').click(function(e){
      e.stopPropagation();
    });

    $('a.btn.koopman').click(function(e){
      e.stopPropagation();
      e.preventDefault();
    });

    $('a.btn.koopman select').change(function(){
      var $select = $(this);
      var $a = $select.closest('A');
      var $tr = $select.closest('TR');
      var link = $a.attr('href');
      var type = $select.val();
      var gewicht = 0;
      /*
      if(gewicht==0){ //vrij op te geven gewicht
        gewicht = prompt('Geef het gewicht op','1');
        if(gewicht == null)gewicht = 0;
        gewicht = parseInt(gewicht);
        if(isNaN(gewicht))gewicht = 0;
      }
      */
      // if(gewicht>0){
      //   link += '&gewicht=' + gewicht;

      //   var d = new Date();
      //   var n = d.getDay();

      //   if(n==5 && ($tr.find('td:eq(4)').html().indexOf('Nederland') != -1)){ //op vrijdag naar Nederland vragen om een zaterdaglevering
      //     if(confirm('Wilt u een Zaterdaglevering? (OK = Ja, Cancel = Nee)')){
      //       link += '&zaterdag=1';
      //     }
      //   }

      //   location.href = link;
      // }

        /*
        *  Gewijzigd door JB Stoker - Moderne Smid
        *  Pakket maten en soorten aangepast, tevens type pakket toegevoegd voor maatvoering
        *  1 -Envelop : (50 x 30 x 1=1Kg) / value = envelope
        *  2 -Plaat : (50 x 30 x 1=15Kg) / value = plaat
        *  3 -1 Meter : (50 x 30 x 1=15Kg) / value = 1-meter
        *  4 -2 Meter < 15 : (50 x 30 x 1= 14Kg) / value = 2-meter-smaller
        *  5 -2 Meter > 15 : (50 x 30 x 1= 30Kg) / value = 2-meter-larger
        *  
        */
       
      if(type != -1){
        switch(type) {
            case 'envelope':
              gewicht = 1; 
              link += '&gewicht=' + gewicht + '&type=envelope';
              break;
            case 'plaat':
              gewicht = 15; 
              link += '&gewicht=' + gewicht + '&type=plaat';
              break;
            case '1-meter':
              gewicht = 10; 
              link += '&gewicht=' + gewicht + '&type=1-meter';
              break;
            case '2-meter-smaller':
              gewicht = 14; 
              link += '&gewicht=' + gewicht + '&type=2-meter-smaller';
              break;
            case '2-meter-larger':
              gewicht = 30; 
              link += '&gewicht=' + gewicht + '&type=2-meter-larger';
              break;
          }

        var d = new Date();
        var n = d.getDay();

        // if(n==5 && ($tr.find('td:eq(4)').html().indexOf('Nederland') != -1)){ //op vrijdag naar Nederland vragen om een zaterdaglevering
        //   if(confirm('Wilt u een Zaterdaglevering? (OK = Ja, Cancel = Nee)')){
        //     link += '&zaterdag=1';
        //   }
        // }
        location.href = link;
      }
    });
  }

  //automatisch pakbonnen printen / scherm verversen
  if($('#subtab-customDeliverySlipsExportAdmin a').length && $('body').hasClass('adminorders')){

    function createCookie(name,value,days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days*24*60*60*1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + value + expires + "; path=/";
    }

    function readCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for(var i=0;i < ca.length;i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
        }
        return null;
    }

    function eraseCookie(name) {
        createCookie(name,"",-1);
    }

    function setupAutoPrintCounter(){
      var ap_timeout = 60;

      var $a = $('#subtab-customDeliverySlipsExportAdmin a');

      var $div = $('<div style="position:absolute;left:230px;top:74px;"></div>');
      var $cb = $('<input type="checkbox" style="float:left;margin-right:10px;cursor:pointer;" id="cb_autoprint"' + (readCookie('cb_autoprint') == 'ja' ? ' checked="checked"' : '') + '/>');
      var $lbl = $('<label for="cb_autoprint" style="float:left;cursor:pointer;">automatisch pakbonnen printen in: ' + ap_timeout + ' seconden</label>');
      $cb.appendTo($div);
      $lbl.appendTo($div);
      $div.appendTo($('.page-head'));

      var ap_counter = ap_timeout;

      $(document).mousemove(function(){
        ap_counter = ap_timeout;
      });

      $cb.change(function(){
        if($cb.is(':checked')){
          createCookie('cb_autoprint','ja',365);
        }else{
          eraseCookie('cb_autoprint');
        }
      });

      setInterval(function(){
        if($cb.is(':checked')){
          ap_counter--;
        }else{
          ap_counter = ap_timeout;
        }
        var lblHtml = 'automatisch pakbonnen printen in: ' + ap_counter + ' seconden';
        if($lbl.html() != lblHtml){
          $lbl.html(lblHtml);
        }

        if(ap_counter == 0){
          ap_counter = ap_timeout;

          var ajaxUrl = $a.attr('href') + '&auto=1&ajax=1';

          $.ajax({
            url: ajaxUrl,
            dataType:'json',
            success: function(data, status, xhr) {
              // console.log(data);
              if(data.printed > 0){
                // console.log('geprint, ververs scherm');
                location.href = data.url; //scherm verversen wanneer geprint
              }else{
                // console.log('niks geprint');
                  //niks doen
              }
            },
            error: function() {
              //iets doen?
              console.log('error in aanroep print url');
            },
            timeout: 58000
          });

        }
      },1000);

    }
    setupAutoPrintCounter();
  }
});