# Moderne smid dynamic product
Module voor actie knoppen t.b.v. de dynamic product module 
