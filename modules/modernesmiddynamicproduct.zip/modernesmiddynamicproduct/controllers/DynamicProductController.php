<?php
use classes\models\DynamicConfig;
use classes\models\DynamicInput;
use classes\models\DynamicField;
use classes\models\DynamicInputField;
use classes\helpers\DynamicCalculatorHelper;
use classes\factory\DynamicFieldFactory;
use classes\DynamicTools;

require_once('DynamicProductConfigurationController.php');
require_once(_PS_MODULE_DIR_.'dynamicproduct'.DIRECTORY_SEPARATOR.'classes'.DIRECTORY_SEPARATOR.'models'.DIRECTORY_SEPARATOR.'DynamicConfig.php');
require_once(_PS_MODULE_DIR_.'dynamicproduct'.DIRECTORY_SEPARATOR.'classes'.DIRECTORY_SEPARATOR.'DynamicTools.php');

class DynamicProductController
{
	private $context;
	private $config;
	private $product;
	private $displayed_container = false;

	public function __construct() {
		$this->context = Context::getContext();
		$this->config = DynamicProductConfigurationController::getInstance();
		$this->messages = array();
	}

	public function getModalParameters($product) {
		$id_product = $product->id;
        $dp_config = new DynamicConfig($id_product);

        if ($this->displayed_container) {
            return false;
        }
        $this->displayed_container = true;

        $output = '';
        if (!$dp_config->active) {
            return false;
        }

        $id_lang = $this->context->language->id;
		return array(
			'product' => $product,
            'dp_config' => $dp_config,
            'dp_fields' => $this->getFieldsByIdProduct($id_product, $id_lang),
			'language' => $this->context->language->id
		);
	}  

    public function getProductInitData($product) {
        $id_product = $product->id;
        $dp_config = new DynamicConfig($id_product);
        
        $id_lang = $this->context->language->id;
        $fields = $this->getFieldsByIdProduct($id_product, $id_lang);
        $behandeling = '';
        foreach ($fields as $key => $field) {
            if($field->name == 'lengte'){
                $lengte = $field->init;

            }
            if($field->name == 'behandeling'){
                $options = $field->getOptions();
                if(!empty($options)){
                    $behandeling = $options[array_key_first($options)]->label;
                } else {
                    $behandeling = '';
                }
            }
        }
        $pricesArr = $this->getDefaultDynamicProductPrices($product, 0);
        if($pricesArr){
            $price = round($pricesArr['unit_prices']['price_ttc'],2).' Incl. btw';
        } else {
            $price = '';
        }
        return array(
            'lengte' => $lengte, 
            'behandeling' => $behandeling, 
            'default_price' => $price, 
        );
    }

	 /**
     * @param $id_product
     * @param $id_lang
     * @return DynamicField[]
     */
    public static function getFieldsByIdProduct($id_product, $id_lang = null)
    {
        $dynamic_fields = array();
        $sql = 'SELECT `id_field`, `type`, `position`, false as linked 
        FROM `' . _DB_PREFIX_ . 'dynamicproduct_field`
        WHERE id_product = ' . (int)$id_product . ' 
        UNION
        (SELECT cf.`id_field`, f.`type`, cf.`position`, true as linked 
        FROM `' . _DB_PREFIX_ . 'dynamicproduct_common_field` cf
        JOIN `' . _DB_PREFIX_ . 'dynamicproduct_field` f
        ON f.`id_field` = cf.`id_field`
        WHERE cf.`id_product` = ' . (int)$id_product . ')
        ORDER BY `position` ASC';
        $rows = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($rows)) {
            $id_field = $row['id_field'];
            $dynamic_field = DynamicFieldFactory::create((int)$row['type'], $id_field, $id_lang);
            $dynamic_field->linked = $row['linked'];
            $dynamic_fields[$id_field] = $dynamic_field;
        }
        return $dynamic_fields;
    }

	public function ajaxRequest($addToCart = false) {
		return Tools::jsonEncode(array('cart' => array()));
	}


    public function getDefaultDynamicProductPrices($product, $attribute){
        if(is_array($product)){
            $id_product = $product['id_product'];
        } else {
            $id_product = $product->id;
        }
        $dp_config = new DynamicConfig($id_product);
        $id_lang = $this->context->language->id;
        $fetched_fields = $this->getFieldsByIdProduct($id_product, $id_lang);


        $input_fields = [];

        foreach ($fetched_fields as $fieldId => $field) {
                $dynamicField =  new DynamicInputField($fieldId, $id_lang);
                    $dynamicField->id_product = $id_product;
                    $dynamicField->id_field = $fieldId;
                    $dynamicField->name = $field->name;
                    $dynamicField->options = $field->options;
                    $dynamicField->type = $field->type;
                    $dynamicField->visible = 1;
                    $dynamicField->disabled = 0;
                    $dynamicField->width = 0;
                    $dynamicField->height = 0;
                    $dynamicField->size = 0;
                    $dynamicField->label = $field->label;
                if(count($field->options) > 0){  
                    $dynamicField->value = $field->options[array_key_first($field->options)]->value;
                    $dynamicField->selected_options = array_key_first($field->options);
                } else {
                    $dynamicField->value = $field->init;
                }
                $input_fields[$field->name] = $dynamicField;
            
            }

        $dynamicField =  new DynamicInputField(0, $id_lang);
        $dynamicField->id_product = $id_product;
        $dynamicField->id_field = 0;
        $dynamicField->name = "quantity";
        $dynamicField->value = 1;
        $dynamicField->options = "[]";
        $dynamicField->type = 0;
        $dynamicField->visible = 1;
        $dynamicField->disabled = 0;
        $dynamicField->width = 0;
        $dynamicField->height = 0;
        $dynamicField->size = 0;
        $dynamicField->label = "Quantity";
        $input_fields['quantity'] = $dynamicField;

        $dynamicField =  new DynamicInputField(0, $id_lang);
        $dynamicField->id_product = $id_product;
        $dynamicField->id_field = 0;
        $dynamicField->name = "product_weight";
        $dynamicField->value = $product['weight'];
        $dynamicField->options = "[]";
        $dynamicField->type = 0;
        $dynamicField->visible = 1;
        $dynamicField->disabled = 0;
        $dynamicField->width = 0;
        $dynamicField->height = 0;
        $dynamicField->size = 0;
        $dynamicField->label = "Weight";

        $input_fields['product_weight'] = $dynamicField;


        $helper = new DynamicCalculatorHelper(Module::getInstanceByName('dynamicproduct'), Context::getContext());
        
        if(!Tools::getIsset('adapter_data')){
            $adapter_data = Tools::getValue('adapter_data');
        } else {
            $adapter_data = array(
              'adapter_data' => array(
                'prices' => array(
                    $id_product => array('price_ht'=> 0,
                    'price_ht_nr'=> 0,
                    'price_ttc'=> 0,
                    'price_ttc_nr'=> 0
                )
            )
        )
    );
        }
        $prices = $helper->getCalculatedPrices($id_product, 0, $input_fields, $adapter_data);

        return $prices;
    }
        
	
}