<?php
require_once(_PS_CORE_DIR_.'/config/config.inc.php');
require_once(_PS_CORE_DIR_.'/init.php');

class modernesmiddynamicproductAjaxModuleFrontController extends ModuleFrontController
{

  public function __construct()
  {
        parent::__construct();
        $this->action = Tools::getValue('action');
        $this->method = Tools::getValue('method');
        $this->dynamicProductController =  new DynamicProductController();
    }

  public function initContent()
  {
      $this->ajax = true;
      if ($this->errors){
              die(Tools::jsonEncode(array('hasError' => true, 'errors' => $this->errors)));
       }

    switch ($this->method) {
        case 'adddynamicproducttocart':
          die( $this->dynamicProductController->ajaxRequest(true));
        break;
        case 'getdynamicproductmodal' :
          echo ($this->module->renderDynamicProductModal());
          die();
          break;
        default:
          die(Tools::jsonEncode( array('error'=>'no method')));
        }
  }
}