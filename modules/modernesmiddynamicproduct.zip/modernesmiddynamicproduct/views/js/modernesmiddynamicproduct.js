$(function() {
  function getMoneyString(price) {
    const formatter = new Intl.NumberFormat('nl-NL', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 2
    });
    return formatter.format(price);
  }
  //Product list functions
  $(document).on('click', 'button.dynamicproduct-button', function(e) {
    $.ajax({
      url: 'module/modernesmiddynamicproduct/ajax',
      type: 'GET',
      data: 'method=getdynamicproductmodal&product=' + $(this).data('product-id') + '&ajax=true',
      success: function(html) {
        $('#dynamicproduct-modal').html(html);
        _updateFormValuesProductList();
      }
    });
  });

  $(document).on('change', '.dynamicproductform .dp_entry, .dynamicproductform .quantity', function(event) {
    event.preventDefault();
    var elem = $(this);
    var val = Number(elem.val());
    var max = Number(elem.attr('data-max'));
    var min = Number(elem.attr('data-min'));
    if (max > 0) {
      if (val < min) {
        elem.val(min);
      }

      if (val > max) {
        elem.val(max);
      }

    }
    _updateFormValuesProductList($(this));
  });
  $(document).on('click', '.dynamicproductform .addToCart', function(event) {
    event.preventDefault();
    _setCustomizationProductList();
  });

  function _getObjectValuesProductList(changedFieldElement, model = 'calculator', action = 'calculate_result') {
    var input = $('.dynamicproductform .dp_entry.dp_input');
    var select = $('.dynamicproductform .dp_entry.dp_dropdown');
    var quantity = $('.dynamicproductform .quantity');
    var productId = Number($('.dynamicproductform #product-id').val());
    var changedField = '';
    if ($(changedFieldElement).hasClass('dp_input')) {
      changedField = 'lengte';
    }
    if ($(changedFieldElement).hasClass('dp_dropdown')) {
      changedField = 'behandeling';
    }
    return {
      'model': model,
      'action': action,
      'changed_field': changedField,
      'fields[lengte][id_product]': Number(productId),
      'fields[lengte][id_field]': Number(input.attr('data-id')),
      'fields[lengte][name]': 'lengte',
      'fields[lengte][value]': Number(input.val()),
      'fields[lengte][options]': "[]",
      'fields[lengte][type]': Number(input.attr('data-type')),
      'fields[lengte][visible]': Number(input.length),
      'fields[lengte][disabled]': input.attr('disabled') == undefined ? 0 : Number(input.attr('disabled')),
      'fields[lengte][width]': input.attr('width') == undefined ? 0 : Number(input.attr('width')),
      'fields[lengte][height]': input.attr('height') == undefined ? 0 : Number(input.attr('height')),
      'fields[lengte][size]': input.attr('size') == undefined ? 0 : Number(input.attr('size')),
      'fields[behandeling][id_product]': Number(productId),
      'fields[behandeling][id_field]': Number(select.attr('data-id')),
      'fields[behandeling][name]': 'behandeling',
      'fields[behandeling][value]': Number(select.find('option:selected').val()),
      'fields[behandeling][options]': "[" + select.find('option:selected').attr('data-id') + "]",
      'fields[behandeling][type]': Number(select.attr('data-type')),
      'fields[behandeling][visible]': Number(select.length),
      'fields[behandeling][disabled]': select.attr('disabled') == undefined ? 0 : Number(select.attr('disabled')),
      'fields[behandeling][width]': select.attr('width') == undefined ? 0 : Number(select.attr('width')),
      'fields[behandeling][height]': select.attr('height') == undefined ? 0 : Number(select.attr('height')),
      'fields[behandeling][size]': select.attr('size') == undefined ? 0 : Number(select.attr('size')),
      'fields[behandeling][selected_options][]': Number(select.find('option:selected').attr('data-id')),
      'fields[quantity][id_product]': Number(productId),
      'fields[quantity][id_field]': 0,
      'fields[quantity][name]': 'quantity',
      'fields[quantity][value]': Number(quantity.val()),
      'fields[quantity][options]': "[]",
      'fields[quantity][type]': 0,
      'fields[quantity][visible]': Number(quantity.length),
      'fields[quantity][disabled]': quantity.attr('disabled') == undefined ? 0 : Number(quantity.attr('disabled')),
      'fields[quantity][width]': quantity.attr('width') == undefined ? 0 : Number(quantity.attr('width')),
      'fields[quantity][height]': quantity.attr('height') == undefined ? 0 : Number(quantity.attr('height')),
      'fields[quantity][size]': quantity.attr('size') == undefined ? 0 : Number(quantity.attr('size')),
      'id_product': Number(productId),
      'id_attribute': 0,
      'ajax': true,
      'hash': prestashop.token,
      '_token': prestashop.token,
      'dp_cart': prestashop.cart.id_cart == undefined ? 0 : Number(prestashop.cart.id_cart),
      'dp_customer': prestashop.customer.id_customer == undefined ? 0 : Number(prestashop.customer.id_customer),
    };
  }

  function _updateFormValuesProductList(changedFieldElement) {
    $.ajax({
        url: '/module/dynamicproduct/calculator',
        type: 'POST',
        dataType: 'JSON',
        data: _getObjectValuesProductList(changedFieldElement),
      })
      .done(function(e) {
        if (e.success == 1) {
          var weight = (Number(e.weight) / 1000) * Number(e.input_fields.lengte.value);
          $('.dynamicproductform .dp_weight_str .weight').text(weight.toFixed(2));
          $('.dynamicproductform #price_excl_no_addition span.subtotal-inc-price').text(e.formatted_prices.price_ht_nr);
          $('.dynamicproductform #dynamicproduct_discount_price span.subtotal-inc-price').text('€ ' + (Number(e.final_prices.price_ht_nr) - Number(e.final_prices.price_ht)));
          $('.dynamicproductform #total_price_excl span.subtotal-inc-price').text(e.formatted_prices.price_ht);
          $('.dynamicproductform #total span.subtotal-inc-price').text(e.formatted_prices.price_ttc);
        } else {
          // console.log("failed");
        }
      });
  }

  function _setCustomizationProductList() {
    $.ajax({
        url: '/module/dynamicproduct/customization',
        type: 'POST',
        dataType: 'JSON',
        data: _getObjectValuesProductList('', 'customization', 'save_customization'),
      })
      .done(function(customizationData) {
        var productId = Number($('.dynamicproductform #product-id').val());
        var quantity = $('.dynamicproductform .quantity').val();

        if (customizationData.success === true) {
          $.ajax({
              url: '/winkelmandje',
              type: 'POST',
              data: {
                token: prestashop.token,
                ajax: 1,
                id_product: productId,
                id_customization: customizationData.id_customization,
                id_attribute: customizationData.id_attribute,
                qty: quantity,
                add: 1,
                action: 'update'
              },
            })
            .done(function(shoppingcartData) {
              var response = JSON.parse(shoppingcartData);
              //Display any messages
              prestashop.emit('updateCart', {
                reason: response
              });

              // console.log(["success", shoppingcartData]);
            });

        } else {
          // console.log('failed');
        }
      });
  }
  //End Product list functions



  // Start product view
  $(document).on('change', '#dynamicproduct-productform .dp_entry, #dynamicproduct-productform .quantity', function(event) {
    event.preventDefault();
    var elem = $(this);
    var val = Number(elem.val());
    var max = Number(elem.attr('data-max'));
    var min = Number(elem.attr('data-min'));
    if (max > 0) {
      if (val < min) {
        elem.val(min);
      }

      if (val > max) {
        elem.val(max);
      }

    }
    _updateFormValuesProductView($(this));
  });
  $(document).on('click', '.addToCartProductView', function(event) {
    event.preventDefault();
    _setCustomizationProductView();
  });

  function _getObjectValuesProductView(changedFieldElement, model = 'calculator', action = 'calculate_result', dp_id_input = null) {
    var input = $('#dynamicproduct-productform .dp_entry.dp_input');
    var select = $('#dynamicproduct-productform .dp_entry.dp_dropdown');
    var quantity = $('#dynamicproduct-productform .quantity');
    var productId = Number($('#dynamicproduct-productform #product-id').val());
    var changedField = '';
    if ($(changedFieldElement).hasClass('dp_input')) {
      changedField = 'lengte';
    }
    if ($(changedFieldElement).hasClass('dp_dropdown')) {
      changedField = 'behandeling';
    }
    return {
      'model': model,
      'action': action,
      'changed_field': changedField,
      'fields[lengte][id_product]': Number(productId),
      'fields[lengte][id_field]': Number(input.attr('data-id')),
      'fields[lengte][name]': 'lengte',
      'fields[lengte][value]': Number(input.val()),
      'fields[lengte][options]': "[]",
      'fields[lengte][type]': Number(input.attr('data-type')),
      'fields[lengte][visible]': Number(input.length),
      'fields[lengte][disabled]': input.attr('disabled') == undefined ? 0 : Number(input.attr('disabled')),
      'fields[lengte][width]': input.attr('width') == undefined ? 0 : Number(input.attr('width')),
      'fields[lengte][height]': input.attr('height') == undefined ? 0 : Number(input.attr('height')),
      'fields[lengte][size]': input.attr('size') == undefined ? 0 : Number(input.attr('size')),
      'fields[behandeling][id_product]': Number(productId),
      'fields[behandeling][id_field]': Number(select.attr('data-id')),
      'fields[behandeling][name]': 'behandeling',
      'fields[behandeling][value]': Number(select.find('option:selected').val()),
      'fields[behandeling][options]': "[" + select.find('option:selected').attr('data-id') + "]",
      'fields[behandeling][type]': Number(select.attr('data-type')),
      'fields[behandeling][visible]': Number(select.length),
      'fields[behandeling][disabled]': select.attr('disabled') == undefined ? 0 : Number(select.attr('disabled')),
      'fields[behandeling][width]': select.attr('width') == undefined ? 0 : Number(select.attr('width')),
      'fields[behandeling][height]': select.attr('height') == undefined ? 0 : Number(select.attr('height')),
      'fields[behandeling][size]': select.attr('size') == undefined ? 0 : Number(select.attr('size')),
      'fields[behandeling][selected_options][]': Number(select.find('option:selected').attr('data-id')),
      'fields[quantity][id_product]': Number(productId),
      'fields[quantity][id_field]': 0,
      'fields[quantity][name]': 'quantity',
      'fields[quantity][value]': Number(quantity.val()),
      'fields[quantity][options]': "[]",
      'fields[quantity][type]': 0,
      'fields[quantity][visible]': Number(quantity.length),
      'fields[quantity][disabled]': quantity.attr('disabled') == undefined ? 0 : Number(quantity.attr('disabled')),
      'fields[quantity][width]': quantity.attr('width') == undefined ? 0 : Number(quantity.attr('width')),
      'fields[quantity][height]': quantity.attr('height') == undefined ? 0 : Number(quantity.attr('height')),
      'fields[quantity][size]': quantity.attr('size') == undefined ? 0 : Number(quantity.attr('size')),
      'id_product': Number(productId),
      'id_attribute': 0,
      'dp_id_input': dp_id_input,
      'ajax': true,
      'hash': prestashop.token,
      '_token': prestashop.token,
      'dp_cart': prestashop.cart.id_cart == undefined ? 0 : Number(prestashop.cart.id_cart),
      'dp_customer': prestashop.customer.id_customer == undefined ? 0 : Number(prestashop.customer.id_customer),
    };
  }

  function _updateFormValuesProductView(changedFieldElement) {
    $.ajax({
        url: '/module/dynamicproduct/calculator',
        type: 'POST',
        dataType: 'JSON',
        data: _getObjectValuesProductView(changedFieldElement),
      })
      .done(function(e) {
        if (e.success == 1) {
          var weight = (Number(e.weight) / 1000) * Number(e.input_fields.lengte.value);
          $('.product-information.row  .dp_weight_str .weight').text(weight.toFixed(2));
          if (e.final_prices.price_ttc !== e.final_prices.price_ttc_nr) {
            $('.product-information.row .product-price  span.regular-price').text(getMoneyString(Number(e.final_prices.price_ttc_nr)));
          } else {
            $('.product-information.row .product-price  span.regular-price').text('');
          }
          $('.product-information.row .product-price span.inclusive-price').text(getMoneyString(e.final_prices.price_ttc) + ' Incl. btw');
          $('.product-information.row .product-price span.exclusive-price').text(getMoneyString(e.final_prices.price_ht) + ' Excl. btw');
        } else {
          // console.log("failed");
        }
      });
  }

  function _setCustomizationProductView() {
    var dpIdInput = $('.addToCartProductView').attr('data-dp-id-input');
    if (dpIdInput == false) {
      dpIdInput = null;
    }
    $.ajax({
        url: '/module/dynamicproduct/customization',
        type: 'POST',
        dataType: 'JSON',
        data: _getObjectValuesProductView('', 'customization', 'save_customization', dpIdInput),
      })
      .done(function(customizationData) {
        var productId = Number($('#dynamicproduct-productform #product-id').val());
        var quantity = $('#dynamicproduct-productform .quantity').val();

        if (customizationData.success === true) {
          $.ajax({
              url: '/winkelmandje',
              type: 'POST',
              data: {
                token: prestashop.token,
                ajax: 1,
                id_product: productId,
                id_customization: customizationData.id_customization,
                id_attribute: customizationData.id_attribute,
                qty: quantity,
                add: 1,
                action: 'update'
              },
            })
            .done(function(shoppingcartData) {
              var response = JSON.parse(shoppingcartData);
              //Display any messages
              prestashop.emit('updateCart', {
                reason: response
              });

              // console.log(["success", shoppingcartData]);
            });

        } else {
          // console.log('failed');
        }
      });
  }
});
