<?php
declare(strict_types=1);

/**
 *
 */
class PriceModifierController extends ModuleAdminController
{
    /**
     * @var int
     */
    private $id_lang;

    public function __construct()
    {
        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();
    }
}
