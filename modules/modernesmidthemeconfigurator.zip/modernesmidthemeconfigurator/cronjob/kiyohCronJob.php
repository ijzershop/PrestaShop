 <?php
/**
 * Cronjob to fetch all latest kiyoh reviews and save them in the database
 * To keep an updated overview page this cron needs to be run between every 5 to 15 minutes.
 *
 */

 /**
  *
  */


 class RunKiyohCronjob
 {
     public function __construct()
     {
         $this->kiyohToken = 'e1fk9hurmsnjxrv';
         $this->kiyohUrl = 'https://www.kiyoh.com/v1/review/feed.xml';
         $this->totalReviewsPerPage = 10;

         $this->parameters = require dirname(__FILE__) . '/../../../app/config/parameters_backup.php';

         $this->serverName = $this->parameters['parameters']['database_host'];
         $this->databaseName = $this->parameters['parameters']['database_name'];
         $this->databaseUserName = $this->parameters['parameters']['database_user'];
         $this->databaseUserPass = $this->parameters['parameters']['database_password'];
         $this->databaseKyohTable = $this->parameters['parameters']['database_prefix'].'kiyoh_custom';
         $this->databaseKyohTableRecordId = 1;
     }

     public function fetchLatestReviews()
     {
         // Get cURL resource
         $curl = curl_init();

         curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
         curl_setopt($curl, CURLOPT_URL, $this->kiyohUrl.'?hash='.$this->kiyohToken.'&pageNumber=1&limit='.$this->totalReviewsPerPage);
         curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
         curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
         curl_setopt($curl, CURLOPT_HEADER, false);
         curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
         // Send the request & save response to $resp
         $resp = curl_exec($curl);

         if (curl_errno($curl)) {
             echo 'Request Error:'.curl_error($curl);
         }
         // Close request to clear up some resources
         curl_close($curl);

         return $resp;
     }

     public function readXmlStream($response)
     {
         $xmlFeed = simplexml_load_string($response);
         if ($xmlFeed == false) {
             $this->readXmlStream($response);

             return;
         }

         return json_encode($xmlFeed);
     }

     public function updateValuesInDatabase($xmlJson)
     {
         $servername = $this->serverName;
         $dbname = $this->databaseName;
         $username = $this->databaseUserName;
         $password = $this->databaseUserPass;
         try {
             $conn = new PDO("mysql:host=$servername;dbname=".$dbname, $username, $password);
             // set the PDO error mode to exception
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
             // echo "Connected successfully";
             $xmlArray = json_decode($xmlJson, true);

             $data = [
                 'id' => $this->databaseKyohTableRecordId,
                 'kiyoh_comments_total' => $xmlArray['numberReviews'],
                 'kiyoh_average_percentage' => $xmlArray['percentageRecommendation'],
                 'kiyoh_average' => $xmlArray['averageRating'],
                 'kiyoh_latest_feed' => $xmlJson,
             ];

             $sql = 'UPDATE `'.$this->databaseKyohTable.'` SET kiyoh_comments_total=:kiyoh_comments_total, kiyoh_average_percentage=:kiyoh_average_percentage, kiyoh_average=:kiyoh_average, kiyoh_latest_feed=:kiyoh_latest_feed WHERE id=:id';
             $stmt = $conn->prepare($sql);
             $stmt->execute($data);
         } catch (PDOException $e) {
             echo 'Connection failed: '.$e->getMessage();
         }
         $conn = null;
     }
 }



$cron = new RunKiyohCronjob;
$cron->updateValuesInDatabase($cron->readXmlStream($cron->fetchLatestReviews()));
 ?>
