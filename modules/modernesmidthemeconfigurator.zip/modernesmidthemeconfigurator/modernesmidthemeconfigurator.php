<?php
/**
 * 2007-2020 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2020 PrestaShop SA
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

use PrestaShop\PrestaShop\Adapter\Entity\FileLogger;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use PrestaShopBundle\Form\Admin\Type\FormattedTextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use PrestaShopBundle\Form\Admin\Type\TranslatableType;
use PrestaShop\PrestaShop\Adapter\SymfonyContainer;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use PrestaShop\PrestaShop\Adapter\Entity\Address;
use PrestaShop\PrestaShop\Adapter\Entity\Carrier;
use PrestaShop\PrestaShop\Adapter\Entity\Cart;
use PrestaShop\PrestaShop\Adapter\Entity\CartRule;
use PrestaShop\PrestaShop\Adapter\Entity\Category;
use PrestaShop\PrestaShop\Adapter\Entity\Configuration;
use PrestaShop\PrestaShop\Adapter\Entity\Contact;
use PrestaShop\PrestaShop\Adapter\Entity\Context;
use PrestaShop\PrestaShop\Adapter\Entity\Customer;
use PrestaShop\PrestaShop\Adapter\Entity\Db;
use PrestaShop\PrestaShop\Adapter\Entity\Dispatcher;
use PrestaShop\PrestaShop\Adapter\Entity\Feature;
use PrestaShop\PrestaShop\Adapter\Entity\FeatureValue;
use PrestaShop\PrestaShop\Adapter\Entity\FormField;
use PrestaShop\PrestaShop\Adapter\Entity\Mail;
use PrestaShop\PrestaShop\Adapter\Entity\Media;
use PrestaShop\PrestaShop\Adapter\Entity\Order;
use PrestaShop\PrestaShop\Adapter\Entity\PrestaShopDatabaseException;
use PrestaShop\PrestaShop\Adapter\Entity\PrestaShopException;
use PrestaShop\PrestaShop\Adapter\Entity\PrestaShopLogger;
use PrestaShop\PrestaShop\Adapter\Entity\Product;
use PrestaShop\PrestaShop\Adapter\Entity\SpecificPrice;
use PrestaShop\PrestaShop\Adapter\Entity\Store;
use PrestaShop\PrestaShop\Adapter\Entity\Tools;
use PrestaShop\PrestaShop\Adapter\Entity\Validate;
use PrestaShop\PrestaShop\Adapter\Entity\Zone;
use PrestaShop\PrestaShop\Core\Domain\Category\Exception\CategoryException;
use PrestaShop\PrestaShop\Core\Domain\Customer\Exception\CustomerException;
use PrestaShop\PrestaShop\Core\Localization\Exception\LocalizationException;
use PrestaShop\PrestaShop\Core\Module\Exception\ModuleErrorException;
use Symfony\Component\Form\FormBuilderInterface;

use ModernesmidThemeConfigurator\Lib\ModernConfigurator;
use ModernesmidThemeConfigurator\Lib\ModernHook;

if (!defined(_PS_VERSION_)) {
    exit;
}

/**
 * Class ModernesmidThemeConfigurator.
 */
class ModernesmidThemeConfigurator extends Module
{
    public $tabs = array(
        array(
            'name' => 'Thema Configuratie', // One name for all langs
            'class_name' => 'AdminThemeConf',
            'visible' => true,
            'parent_class_name' => 'AdminParentThemes',
        )
    );

    public function __construct()
    {
        $this->name = 'modernesmidthemeconfigurator';
        $this->author = 'ijzershop';
        $this->need_instance = 1;
        $this->bootstrap = (bool)true;
        $this->version = '2.0.0';

        parent::__construct();

        $this->displayName = $this->trans('Moderne Smid Theme Configurator', [],
            'Modules.ModernesmidThemeConfigurator.modernesmidthemeconfigurator.php');
        $this->description = $this->trans('Module for the configurations of the Moderne Smid BV', [],
            'Modules.ModernesmidThemeConfigurator.modernesmidthemeconfigurator.php');

        $this->confirmUninstall = $this->trans('Are you sure to remove this module, all records from the database wil be removed',
            [], 'Modules.ModernesmidThemeConfigurator.modernesmidthemeconfigurator.php');

        $this->ps_versions_compliancy = [
            'min' => '1.7',
            'max' =>'8.99.99'
        ];

        $this->context = Context::getContext();
        $this->idShop = $this->context->shop->id;
        $this->idShopGroup = $this->context->shop->getGroup()->id;
        $this->idLang = $this->context->language->id;
        $this->hookClass = new ModernHook($this->module, $this->context);
    }
    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update.
     */
    public function install()
    {
        Configuration::updateValue('MODERNESMIDTHEMECONFIGURATOR_LIVE_MODE', false);
        return parent::install() && $this->installHooks($this);

    }
    /**
     * @param $moduleClass
     * @return bool|void
     */
    private function installHooks(){
        $hookArray = [
            'filterProductContent',
            'displayBackOfficeHeader',
            'displayFooter',
            'displayCMSDisputeInformation',
            'displayAdminProductsSeoStepBottom',
            'displayAdditionalCustomerAddressFields',
            'displayAdditionalCategoryFields',
            'displayAdditionalRootCategoryFields',
            'displayPDFDeliverySlip',
            'displayOrderConfirmation',
            'kiyohBanner',
            'actionFrontControllerSetMedia',
            'actionFrontControllerAfterInit',
            'actionBuildFrontEndObject',
            'actionCustomerAccountAdd',
            'actionAfterUpdateCustomerAddressFormHandler',
            'actionAfterCreateCustomerAddressFormHandler',
            'actionAfterUpdateRootCategoryFormHandler',
            'actionAfterCreateRootCategoryFormHandler',
            'actionCategoryFormBuilderModifier',
            'actionAfterUpdateCategoryFormHandler',
            'actionAfterCreateCategoryFormHandler',
            'actionRootCategoryFormBuilderModifier',
            'actionAdminProductsControllerSaveAfter',
            'actionAddressFormBuilderModifier',
            'actionAfterCreateAddressFormHandler',
            'actionCustomerAddressFormBuilderModifier',
            'actionAfterUpdateOrderAddressFormHandler',
            'actionProductSearchProviderRunQueryAfter',
            'actionOrderStatusPostUpdate'
        ];



        $logger = new FileLogger(0);

        $sep = DIRECTORY_SEPARATOR;

        $logger->setFilename(_PS_ROOT_DIR_ . $sep.'var'.$sep.'logs'.$sep.'modernesmidthemeconfigurator.log');
        $allOK = false;
        foreach ($hookArray as $hook) {
            $hookName = 'hook' . ucfirst($hook);

            if (method_exists($this, $hookName)) {
                if ($this->registerHook($hook)) {
                    $allOK = true;
                } else {
                    $logger->logDebug('Registration of hook ' . $hook . ' failed');
                    $allOK = false;
                }
            } else {
                $logger->logDebug($hookName . ' function does not exist');
                $allOK = false;
            }
        }
        return $allOK;
    }
    /**
     * @return bool
     */
    public function uninstall()
    {
        return parent::uninstall() && Configuration::deleteByName('MODERNESMIDTHEMECONFIGURATOR_LIVE_MODE');
    }
    /**
     * Upload an new file
     *
     * @param $file
     * @param $dest
     * @return mixed|void
     */
    protected function uploadFiles($file, $dest = null)
    {
        // Upload files
        $allowed = [
            'png',
            'jpeg',
            'gif',
            'jpg',
            'svg',
        ];
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        if (file_exists($file['tmp_name']) && in_array($extension, $allowed)) {
            $filename = uniqid() . '-' . basename($file['name']);
            $filename = str_replace(' ', '-', $filename);
            $filename = strtolower($filename);
            $filename = filter_var($filename, FILTER_SANITIZE_STRING);

            $file['name'] = $filename;

            $uploader = new UploaderCore();
            $uploader->upload($file, $dest);

            return $file['name'];
        }
    }
    /**
     * Load the configuration form.
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitModerneSmidThemeModuleConfigurator')) == true) {
            $this->postProcess();
        }

        $modernConfig = new ModernConfigurator($this);
        $ajaxUrl = $modernConfig->getAjaxUrl();
        $select2Url = str_replace('%20','', $modernConfig->getSelect2Url());
        $access =  $modernConfig->getAccessiblePanelsUser($this->context->employee->id_profile);

        $viewData = [
                'ajax_url' => $ajaxUrl,
                'module_dir' => $this->_path,
                'select2_url' => $select2Url,
                'employee_access' => $access
            ];

        $page = $modernConfig->getConfigPage($viewData);

        return $page;
    }
    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $imgKeys = [
            'MODERNESMIDTHEMECONFIGURATOR_BANNER_FIRST_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_BANNER_SECOND_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_BANNER_THIRD_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_BANNER_FOURTH_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_BANNER_FIFTH_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERBOTTOM_FIRST_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERBOTTOM_SECOND_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERBOTTOM_THIRD_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERBOTTOM_FOURTH_IMAGE',
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERBOTTOM_FIFTH_IMAGE',
        ];

        $textareaKeys = [
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERTOP_ABOUTUS_TEXT',
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERTOP_ABOUTUS_LINK',
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERTOP_INFORMATION',
            'MODERNESMIDTHEMECONFIGURATOR_FOOTERTOP_PARTNERS',
            'MODERNESMIDTHEMECONFIGURATOR_HOMEPAGE_TEXT',
            'MODERNESMIDTHEMECONFIGURATOR_SHOP_NOTIFICATION_TEXT',
            'MODERNESMIDTHEMECONFIGURATOR_CATEGORY_BOTTOM_TEXT',
            'MODERNESMIDTHEMECONFIGURATOR_CONTACTPAGE_CONTACTINFORMATION_TEXT',
            'MODERNESMIDTHEMECONFIGURATOR_CONTACTPAGE_CONTACTOFFER_TEXT',
        ];

        $multipleSelectKeys = [
            'MODERNESMIDTHEMECONFIGURATOR_HOMEPAGE_CATEGORIES[]',
            'MODERNESMIDTHEMECONFIGURATOR_CHANNABLE_CATEGORIES[]',
            'MODERNESMIDTHEMECONFIGURATOR_SHOP_NOTIFICATION_PAGES[]',
            'MODERNESMIDTHEMECONFIGURATOR_EMPLOYEE_WORKSHOP_PROFILES[]',
            'MODERNESMIDTHEMECONFIGURATOR_EMPLOYEE_SHOP_PROFILES[]',
            'MODERNESMIDTHEMECONFIGURATOR_FEATURE_ENABLED[]',
        ];

        $form_values = Tools::getAllValues();
        foreach (array_keys($form_values) as $key) {
            if(!preg_match('/^[A-Z0-9_]+$/', $key)){
                continue;
            }

            //check if is multiple select
            if (in_array($key, $multipleSelectKeys)) {
                switch ($key) {
                    case 'MODERNESMIDTHEMECONFIGURATOR_HOMEPAGE_CATEGORIES[]':
                        $categoriesString = implode(',',
                            json_decode(Tools::getValue('MODERNESMIDTHEMECONFIGURATOR_HOMEPAGE_CATEGORIES_SORTED')));
                        Configuration::updateValue('MODERNESMIDTHEMECONFIGURATOR_HOMEPAGE_SELECTED_CATEGORIES',
                            $categoriesString, false);
                        break;
                    case 'MODERNESMIDTHEMECONFIGURATOR_SHOP_NOTIFICATION_PAGES[]':
                        $categoriesString = implode(',',
                            Tools::getValue('MODERNESMIDTHEMECONFIGURATOR_SHOP_NOTIFICATION_PAGES'));
                        Configuration::updateValue('MODERNESMIDTHEMECONFIGURATOR_SHOP_NOTIFICATION_PAGES',
                            $categoriesString, false);
                        break;
                    case 'MODERNESMIDTHEMECONFIGURATOR_EMPLOYEE_WORKSHOP_PROFILES[]':
                        $profileString = implode(',',
                            Tools::getValue('MODERNESMIDTHEMECONFIGURATOR_EMPLOYEE_WORKSHOP_PROFILES'));
                        Configuration::updateValue('MODERNESMIDTHEMECONFIGURATOR_EMPLOYEE_WORKSHOP_PROFILES',
                            $profileString, false);
                        break;
                    case 'MODERNESMIDTHEMECONFIGURATOR_EMPLOYEE_SHOP_PROFILES[]':
                        $profileString = implode(',',
                            Tools::getValue('MODERNESMIDTHEMECONFIGURATOR_EMPLOYEE_SHOP_PROFILES'));
                        Configuration::updateValue('MODERNESMIDTHEMECONFIGURATOR_EMPLOYEE_SHOP_PROFILES',
                            $profileString, false);
                        break;
                    case 'MODERNESMIDTHEMECONFIGURATOR_FEATURE_ENABLED[]':
                        $featureString = implode(',', Tools::getValue('MODERNESMIDTHEMECONFIGURATOR_FEATURE_ENABLED'));
                        Configuration::updateValue('MODERNESMIDTHEMECONFIGURATOR_FEATURE_ENABLED', $featureString,
                            false);
                    case 'MODERNESMIDTHEMECONFIGURATOR_CHANNABLE_CATEGORIES[]':
                        $categoriesString = implode(',',
                            Tools::getValue('MODERNESMIDTHEMECONFIGURATOR_CHANNABLE_CATEGORIES'));
                        Configuration::updateValue('MODERNESMIDTHEMECONFIGURATOR_CHANNABLE_SELECTED_CATEGORIES',
                            $categoriesString, false);
                        break;
                }

                continue;
            }

            if (in_array($key, $imgKeys) && $_FILES[$key]['name'] == '') {
                continue;
            }
            if (in_array($key, $imgKeys)) {
                $file = $this->uploadFiles($_FILES[$key]);
                Configuration::updateValue($key, $file);
            } elseif (in_array($key, $textareaKeys)) {
                // Has html elements
                Configuration::updateValue($key, Tools::getValue($key), true);
            } elseif ($key == 'MODERNESMIDTHEMECONFIGURATOR_ORDERSTATE_SENDMAIL_JSON') {
                $orderStateIds = Tools::getValue('SENDMAIL_ORDER_STATUS');
                $orderStateFirstEmails = Tools::getValue('SENDMAIL_ORDER_STATUS_FIRST_EMAIL');
                $orderStateSecondEmails = Tools::getValue('SENDMAIL_ORDER_STATUS_SECOND_EMAIL');
                $orderStateIdEmailArr = [];
                $orderStateJSON = '';

                if (is_array($orderStateIds) && count($orderStateIds) > 0) {
                    for ($i = 0; $i < count($orderStateIds); $i++) {
                        $orderStateIdEmailArr[$i] = [];
                        $orderStateIdEmailArr[$i]['id_order_state'] = $orderStateIds[$i];
                        $orderStateIdEmailArr[$i]['first_email_order_state'] = $orderStateFirstEmails[$i];
                        $orderStateIdEmailArr[$i]['second_email_order_state'] = $orderStateSecondEmails[$i];
                    }

                    $orderStateJSON = json_encode($orderStateIdEmailArr);
                }
                Configuration::updateValue($key, $orderStateJSON, false);
            } else {
                //is only text
                Configuration::updateValue($key, Tools::getValue($key), false);
            }
        }
    }

    /**
     * List of all Hooks
     */
    public function hookDisplayHome($hookArgs){
       return $this->hookClass->hookDisplayHome($hookArgs);
    }
    public function hookDisplayOrderConfirmation($params){
       return $this->hookClass->hookDisplayOrderConfirmation($params);
    }
    public function hookDisplayPDFDeliverySlip($hookArgs){
       return $this->hookClass->hookDisplayPDFDeliverySlip($hookArgs);
    }
    public function hookFilterProductContent(array $params){
       return $this->hookClass->hookFilterProductContent($params);
    }
    public function hookActionProductSearchProviderRunQueryAfter($hookArgs){
       return $this->hookClass->hookActionProductSearchProviderRunQueryAfter($hookArgs);
    }
    public function hookActionBuildFrontEndObject($params){
       return $this->hookClass->hookActionBuildFrontEndObject($params);
    }
    public function hookDisplayAdminProductsSeoStepBottom($params){
       return $this->hookClass->hookDisplayAdminProductsSeoStepBottom($params);
    }
    public function hookActionAdminProductsControllerSaveAfter($params){
       return $this->hookClass->hookActionAdminProductsControllerSaveAfter($params);
    }
    public function hookActionOrderStatusPostUpdate($data){
       return $this->hookClass->hookActionOrderStatusPostUpdate();
    }
    public function hookActionCustomerAccountAdd($customer){
       return $this->hookClass->hookActionCustomerAccountAdd();
    }
    public function hookActionCustomerAddressFormBuilderModifier(array $params){
       return $this->hookClass->hookActionCustomerAddressFormBuilderModifier($params);
    }
    public function hookDisplayAdditionalCustomerAddressFields(array $params){
       return $this->hookClass->hookDisplayAdditionalCustomerAddressFields($params);
    }
    public function hookActionAfterUpdateCustomerAddressFormHandler(array $params){
       return $this->hookClass->hookActionAfterUpdateCustomerAddressFormHandler($params);
    }
    public function hookActionAfterCreateCustomerAddressFormHandler(array $params){
       return $this->hookClass->hookActionAfterCreateCustomerAddressFormHandler($params);
    }
    public function hookActionAfterCreateAddressFormHandler(array $params){
       return $this->hookClass->hookActionAfterCreateAddressFormHandler($params);
    }
    public function hookActionFrontControllerSetMedia($params){
       return $this->hookClass->hookActionFrontControllerSetMedia($params);
    }
    public function hookKiyohBanner(){
       return $this->hookClass->hookKiyohBanner();
    }
    public function hookDisplayCMSDisputeInformation(){
       return $this->hookClass->hookDisplayCMSDisputeInformation();
    }
    public function hookActionFrontControllerAfterInit(){
       return $this->hookClass->hookActionFrontControllerAfterInit();
    }
    public function hookActionCategoryFormBuilderModifier(array $params){
       return $this->hookClass->hookActionCategoryFormBuilderModifier($params);
    }
    public function hookAdditionalCategoryFields(array $params){
       return $this->hookClass->hookAdditionalCategoryFields($params);
    }
    public function hookActionAfterUpdateCategoryFormHandler(array $params){
       return $this->hookClass->hookActionAfterUpdateCategoryFormHandler($params);
    }
    public function hookActionAfterCreateCategoryFormHandler(array $params){
       return $this->hookClass->hookActionAfterCreateCategoryFormHandler($params);
    }
    public function hookActionRootCategoryFormBuilderModifier(array $params){
       return $this->hookClass->hookActionRootCategoryFormBuilderModifier($params);
    }
    public function hookAdditionalRootCategoryFields(array $params){
       return $this->hookClass->hookAdditionalRootCategoryFields($params);
    }
    public function hookActionAfterUpdateRootCategoryFormHandler(array $params){
       return $this->hookClass->hookActionAfterUpdateRootCategoryFormHandler($params);
    }
    public function hookActionAfterCreateRootCategoryFormHandler(array $params){
       return $this->hookClass->hookActionAfterCreateRootCategoryFormHandler($params);
    }
    public function hookActionAfterUpdateOrderAddressFormHandler(array $params){
       return $this->hookClass->hookActionAfterUpdateOrderAddressFormHandler($params);
    }


}

