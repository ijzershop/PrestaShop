<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{modernesmidthemeconfigurator}prestashop>modernesmidthemeconfigurator_c1a3626600b7d8a8b3e0b2474ab5c202'] = 'Huisnummer';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>modernesmidthemeconfigurator_88a6f68163be751ee12f3096e1407b70'] = 'Huisnummer Extensie';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>modernesmidthemeconfigurator_49e918b1d51ec0f52b78429a952a7d40'] = 'Topbeschrijving';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>modernesmidthemeconfigurator_83e2ea971ebb89143392deb2e29ccead'] = 'Tweede naam';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>modernesmidthemeconfigurator_e5c44930e10a65dc60fd1d3f26fdf03c'] = 'Veelgestelde vragen JSON+LD';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>ajax_d4bde7a657e683478be62213418b9855'] = 'Ongeldige postcode';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>ajax_e8f638d8907833cbcead6ba01dd2a954'] = 'Moet als volgt worden getypt:';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>ajax_09737938747269600702609ab170f2f5'] = 'Verplicht veld';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_2f99611739b23d22ba0567dcc6db2155'] = 'Moderne Smid BV Theme Configurator';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_73bd705fabc38653d838fb6d3af74f82'] = 'This module adds extra settings for the ModerneSmid Theme!';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_8a13b7bd0e4d3cff32b11aba5c1da976'] = 'Please enter the needed configurations to use the Moderne Smid BV Theme.';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_40299bc551f066e38c08146afcfea124'] = 'To use pre-formatted snippets you can create your own bootstrap html snippets in the snippets-manager.';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_f7ef87b2ffb531c7c7e39a53641fe80c'] = 'The snippets are grouped into categories these categories are shown as different tabs in the snippet dialog';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_ebe58d219e0fa651b745a32348fa2072'] = 'The Snippets manager allows to:';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_1faa0a9dcbddbd9ebb27349ec6649b27'] = 'add/remove categories & snippets';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_a0299ba6d94ab17abb3cf19ad4ee1eed'] = 'edit the categories names';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_e212fbbb916c2ff7eba70b22b637420f'] = 'edit the snippets names & code';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_ed7d165186381b78ade9a2e41f9ca533'] = 're-order the categories & snippets';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_42bde8a58368b6e5fcb7195985c4d8c4'] = 'The snippets are available in the editor snippets dialog.';
$_MODULE['<{modernesmidthemeconfigurator}prestashop>configure_e03603f5da3ad58e37d2cf8419d3d9ca'] = 'To go to the snippets editor click here';
