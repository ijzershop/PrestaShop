<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{offerintegration}prestashop>offerintegration_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen bijgewerkt';
$_MODULE['<{offerintegration}prestashop>offerintegration_fe5d926454b6a8144efce13a44d019ba'] = 'Ongeldige configuratiewaarde';
$_MODULE['<{offerintegration}prestashop>offerintegration_f4f70727dc34561dfde1a3c529b6205c'] = 'Instellingen';
$_MODULE['<{offerintegration}prestashop>offerintegration_db9b39c5e9f042e8415287d28c84dd0d'] = 'Extra gewicht';
$_MODULE['<{offerintegration}prestashop>offerintegration_c4881fe46ea6c64220179ea95d801f61'] = 'Extra Verzendkosten in %, gebruik . voor decimaal';
$_MODULE['<{offerintegration}prestashop>offerintegration_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{offerintegration}prestashop>offerintegration_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar lijst';
$_MODULE['<{offerintegration}prestashop>oihelperlist_4351cfebe4b61d8aa5efa1d020710005'] = 'Weergave';
$_MODULE['<{offerintegration}prestashop>oihelperlist_7dce122004969d56ae2e0245cb754d35'] = 'Bewerking';
$_MODULE['<{offerintegration}prestashop>oihelperlist_f2a6c498fb90ee345d997f888fce3b18'] = 'Verwijderen';
$_MODULE['<{offerintegration}prestashop>oihelperlist_1412292b09d3cd39f32549afb1f5f102'] = 'Geselecteerd item verwijderen?';
$_MODULE['<{offerintegration}prestashop>oihelperlist_4e140ba723a03baa6948340bf90e2ef6'] = 'Naam:';
$_MODULE['<{offerintegration}prestashop>oihelperlist_bacecdc2dcbfddcf40c24f3df15da4ef'] = 'Weet u zeker dat u deze offerte regel wilt verwijderen?';
$_MODULE['<{offerintegration}prestashop>offer_1e48fdae505982f53572610128a49729'] = 'en vervalt over';
$_MODULE['<{offerintegration}prestashop>offer_c440b394122610d841a6cc0b291329e9'] = 'deze is verlopen op';
$_MODULE['<{offerintegration}prestashop>offer_8bf8854bebe108183caeb845c7676ae4'] = 'van';
$_MODULE['<{offerintegration}prestashop>offer_9e277f0f7f6b36cd968e0a9450f80f59'] = 'neem dan even contact met ons op.';
$_MODULE['<{offerintegration}prestashop>search_79781fe4f18806df7e82fa455184f59b'] = 'Niet gevonden';
$_MODULE['<{offerintegration}prestashop>search_b0e228d2e6bfd33892f5aea10d8d5b02'] = 'Bekijk uw offerte';
$_MODULE['<{offerintegration}prestashop>search_ce1a1625496edb88a92d4370b898953d'] = 'Voer uw persoonlijke code hieronder in.';
$_MODULE['<{offerintegration}prestashop>search_23c9a8dfe6048649144f4f230ece08d1'] = 'Zoeken';
