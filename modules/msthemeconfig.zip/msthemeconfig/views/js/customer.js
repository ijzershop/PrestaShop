$(document).ready(function () {

  $('#customer_informer_identification').select2();

});
