<?php

require_once(_PS_MODULE_DIR_ . 'offerintegration/classes/Offer.php');
require_once(_PS_MODULE_DIR_ . 'offerintegration/classes/OIHelperList.php');

class AdminOfferController extends ModuleAdminController {

	var $filter = array();
	var $orderby = "";
	var $orderway = true;

	public function __construct()
	{
		$this->module = 'offerintegration';
		$this->name = 'offer';
		$this->table = 'oi_offer';
		$this->className = 'Offer';
		$this->lang = false;

		$this->deleted = true;
		$this->addRowAction('edit');
		$this->addRowAction('delete');

		$this->orderBy = 'date_add';
		$this->orderWay = 'DESC';
		$this->context = Context::getContext();
		$this->bootstrap = true;

		$this->bulk_actions = array(
			'delete' => array(
				'text' => Context::getContext()->getTranslator()->trans('Verwijder geselecteerde'),
				'confirm' => Context::getContext()->getTranslator()->trans('Wilt u deze items verwijderen?'),
				'icon' => 'icon-trash'
			)
		);

		$this->fields_form = array(
			'legend' => array(
				'title' => Context::getContext()->getTranslator()->trans('Wijzig offerte')
			),
			'input' => array(
				'code' => array(
					'type' => 'text',
					'name' => 'code',
					'label' => Context::getContext()->getTranslator()->trans('Code'),
					'required' => true
				),
				'name' => array(
					'type' => 'text',
					'name' => 'name',
					'label' => Context::getContext()->getTranslator()->trans('Naam'),
					'required' => true
				),
				'email' => array(
					'type' => 'text',
					'name' => 'email',
					'label' => Context::getContext()->getTranslator()->trans('Email adres'),
					'required' => true
				)
			),
			'submit' => array(
				'title' => Context::getContext()->getTranslator()->trans('Opslaan'),
				'class' => 'btn btn-default pull-right'
			)
		);

		$this->filter = $this->getFilters();
		$this->orderby = $this->getOrderby();
		$this->orderway = $this->getOrderway();

		parent::__construct();


	}

	public function initPageHeaderToolbar()
	{
		if ($this->display != 'view') {
			$this->page_header_toolbar_btn['new_offer'] = array(
				'href' => $this->context->link->getAdminLink('AdminOffer').'&configure=offer&addoi_offer',
				'desc' => Context::getContext()->getTranslator()->trans('Maak nieuwe offerte'),
				'icon' => 'process-icon-new'
			);
		}
		parent::initPageHeaderToolbar();
	}

	/**
	 *
	 */
	public function display(){

		parent::display();
	}

	public function renderList() {
		$fields_list = array(
			'code' => array(
				'title' => Context::getContext()->getTranslator()->trans('Code'),
				'width' => 'auto',
				'type' => 'text',
				'search' => true
			),
			'name' => array(
				'title' => Context::getContext()->getTranslator()->trans('Naam'),
				'width' => 'auto',
				'type' => 'text',
				'search' => true
			),
			'email' => array(
				'title' => Context::getContext()->getTranslator()->trans('Email'),
				'width' => 'auto',
				'type' => 'text',
				'search' => true
			),
			'date_upd' => array(
				'title' => Context::getContext()->getTranslator()->trans('Gewijzigd'),
				'width' => 140,
				'type' => 'datetime'
			)
		);

		$helper = new OIHelperList();

		$helper->shopLinkType = '';
		$helper->simple_header = false;
		$helper->table_id = 'oi_offer';
		$helper->table = 'oi_offer';
		$helper->actions = array( 'view', 'edit', 'delete');

		$helper->identifier = 'id_oi_offer';
		$helper->show_toolbar = true;
		$helper->title = Context::getContext()->getTranslator()->trans('Alle Offertes');
		$helper->specificConfirmDelete = Context::getContext()->getTranslator()->trans('Weet u zeker dat u deze offerte wilt verwijderen?');

		$helper->bulk_actions = $this->bulk_actions = array(
			'delete' => array(
				'text'    => Context::getContext()->getTranslator()->trans('Verwijder geselecteerde'),
				'icon'    => 'icon-trash',
				'confirm' => Context::getContext()->getTranslator()->trans('Wilt u deze items verwijderen?'),
			),
		);

		$helper->token = Tools::getAdminTokenLite('AdminOffer');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
		
		return $helper->generateList(Offer::getAllOffers($this->getFilters(), $this->orderby, $this->orderway), $fields_list);
	}

	public function renderView() {

		if (!($offer = $this->loadObject())) {
			return;
		}

		$this->tpl_view_vars = array(
			'offer' => $offer
		);
		return parent::renderView();
	}

	public function renderForm()
	{
		if (!$this->default_form_language) {
			$this->getLanguages();
		}

		if (Tools::getValue('submitFormAjax')) {
			$this->content .= $this->context->smarty->fetch('form_submit_ajax.tpl');
		}

		if ($this->fields_form && is_array($this->fields_form)) {
			if (!$this->multiple_fieldsets) {
				$this->fields_form = array(array('form' => $this->fields_form));
			}

			// For add a fields via an override of $fields_form, use $fields_form_override
			if (is_array($this->fields_form_override) && !empty($this->fields_form_override)) {
				$this->fields_form[0]['form']['input'] = array_merge($this->fields_form[0]['form']['input'], $this->fields_form_override);
			}

			$fields_value = $this->getFieldsValue($this->object);

			if ($fields_value['code'] == null) {
				$fields_value['code'] = date_format(date_create(), 'Ymd') . '-' . rand ( 1000 , 9999 );
			}

			Hook::exec('action'.$this->controller_name.'FormModifier', array(
				'fields' => &$this->fields_form,
				'fields_value' => &$fields_value,
				'form_vars' => &$this->tpl_form_vars,
			));

			$helper = new HelperForm($this);
			$this->setHelperDisplay($helper);
			$helper->fields_value = $fields_value;
			$helper->submit_action = $this->submit_action;
			$helper->tpl_vars = $this->getTemplateFormVars();
			$helper->show_cancel_button = (isset($this->show_form_cancel_button)) ? $this->show_form_cancel_button : ($this->display == 'add' || $this->display == 'edit');

			$back = Tools::safeOutput(Tools::getValue('back', ''));
			if (empty($back)) {
				$back = self::$currentIndex.'&token='.$this->token;
			}
			if (!Validate::isCleanHtml($back)) {
				die(Tools::displayError());
			}

			$helper->back_url = $back;
			!is_null($this->base_tpl_form) ? $helper->base_tpl = $this->base_tpl_form : '';
			if ($this->tabAccess['view']) {
				if (Tools::getValue('back')) {
					$helper->tpl_vars['back'] = Tools::safeOutput(Tools::getValue('back'));
				} else {
					$helper->tpl_vars['back'] = Tools::safeOutput(Tools::getValue(self::$currentIndex.'&token='.$this->token));
				}
			}
			$form = $helper->generateForm($this->fields_form);

			return $form;
		}
	}

	/**
	 * Delete offer including products
	 * @return ObjectModel|false
	 * @throws PrestaShopException
	 */
	public function processDelete()
	{
		$config = $this->getConfiguration();

		if (Validate::isLoadedObject($object = $this->loadObject()) && is_array($config)) {
			$rows = Product::getOfferRows($object->id, $this->context->language->id);
			foreach ($rows as $row) {
				$product = new Product($row['id_product']);
				if ($config['id_category'] == $product->id_category_default && !$product->delete()) {
					Tools::displayError('Product kon niet verwijderd worden!');
				}
			}
			if (!$object->delete()) {
				Tools::displayError('Offerte kon niet verwijderd worden!');
			}
		}
		return null;
	}

	/**
	 * Delete all selected offers including products
	 * @return bool
	 */
	public function processBulkDelete()
	{
		$config = $this->getConfiguration();
		if (Tools::getIsset($this->table . 'Box') && is_array(Tools::getValue($this->table . 'Box')) && is_array($config)) {
			foreach (Tools::getValue($this->table . 'Box') as $offer_id) {
				//Delete related products
				$rows = Product::getOfferRows($offer_id, $this->context->language->id);
				foreach ($rows as $row) {
					$product = new Product($row['id_product']);
					if ($config['id_category'] == $product->id_category_default && !$product->delete()) {
						return false;
					}
				}
				//Delete offer
				$offer = new Offer($offer_id);
				if (!$offer->delete()) {
					Tools::displayError('Offerte kon niet verwijderd worden!');
					return false;
				}
			}
		}
		return true;
	}
	/**
	 * After adding new product
	 * @param $object
	 * @return bool
	 */
	protected function afterAdd($object)
	{
		if ($object != null && $object instanceof Offer) {
			Tools::redirectAdmin($this->context->link->getAdminLink('AdminOfferRow') . '&id_oi_offer=' . $object->id . '&addproduct');
		}
		return true;
	}

	public function renderDetails()
	{
		return parent::renderDetails();
	}
	
	public function setMedia($isNewTheme=false) {
		parent::setMedia(false);
		$this->addJS(_PS_MODULE_DIR_ . 'offerintegration/views/templates/admin/js/oi_admin.js');
	}

	public function initContent() {
		if ($this->display != null && $this->display == 'view') {
			$offer_id = Tools::getValue('id_oi_offer');
			if (!is_numeric($offer_id))
				return;
			Tools::redirectAdmin($this->context->link->getAdminLink('AdminOfferRow') .
				'&id_oi_offer=' . $offer_id );

		}
 		parent::initContent();
	}

	private function getFilters() {
		$filters = array();
		if (isset($_POST) && count($_POST) > 0) {
			$reset = false;
			if (Tools::getIsset('submitReset'. $this->table)) {
				$reset = true;
			}
			foreach (Offer::$definition['fields'] as $field => $values) {
				if (Tools::getIsset($this->table. 'Filter_' . $field)
					&& Tools::getValue($this->table. 'Filter_' . $field) != ""
					) {
						$value = (!$reset)? Tools::getValue($this->table. 'Filter_' . $field) : "";
					if (is_array($value)) {
						$value = serialize($value);
					}

					$this->context->cookie->{$this->table. 'Filter_' . $field} = $value;
					$filters[$field] = $value;
				}
				else {
					$this->context->cookie->{$this->table. 'Filter_' . $field} = "";
					$filters[$field] = "";
				}
			}
			$this->context->cookie->__set('offer_filters', serialize($filters));
		}
		else {
			$filters = unserialize($this->context->cookie->__get('offer_filters'));
		}
		return $filters;
	}

	private function getOrderby() {
		if (Tools::getIsset($this->table . 'Orderby') && Tools::getValue($this->table . 'Orderby') != null) {
			return Tools::getValue($this->table . 'Orderby');
		}
		return "";
	}

	private function getOrderway() {
		if (Tools::getIsset($this->table . 'Orderway') && Tools::getValue($this->table . 'Orderway') == "desc") {
			return false;
		}
		return true;
	}

	/**
	 * Get last saved configuration
	 * @return array|mixed
	 */
	public function getConfiguration() {
		$configuration = array();
		if (Configuration::get(OfferIntegration::CONFIGURATION_NAME) != null) {
			$configuration = unserialize(Configuration::get(OfferIntegration::CONFIGURATION_NAME));
		}
		return $configuration;
	}
}