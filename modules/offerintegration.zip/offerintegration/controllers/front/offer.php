<?php

class OfferIntegrationOfferModuleFrontController extends ModuleFrontController {

	private	$products = array();

	public function __construct(){
		parent::__construct();
	}

	public function postProcess() {

		$offer_id = null;

		if (Tools::getIsset('offer_code') && preg_match("/^[-0-9A-Za-z]+$/", Tools::getValue('offer_code'))) {
			$result = Offer::getOfferForCode(Tools::getValue('offer_code'));
			if ($result != null && count($result) == 1) {
				$offer_id = $result[0]['id_oi_offer'];
			}
		}
		if ($offer_id == null && Tools::getIsset('id_oi_offer') && is_numeric(Tools::getValue('id_oi_offer'))) {
			$offer_id = Tools::getValue('id_oi_offer');
		}

		if ($offer_id != null) {
			//get products for offer
			$this->products = Product::getOfferRows($offer_id, $this->context->language->id);
		}
	}

	public function setMedia($theme = null) {
		parent::setMedia();
		$this->context->controller->addCSS(_THEME_CSS_DIR_.'product_list.css', 'all');
		$this->context->controller->addJs(_THEME_JS_DIR_.'category.js');
		return;
	}

	public  function initContent()
	{
		parent::initContent();

		$this->context->smarty->assign(array(
			'products' =>  $this->products
		));

		$this->setTemplate('module:offerintegration/views/templates/front/offer.tpl');
	}



}