<?php

require_once(_PS_MODULE_DIR_ . 'offerintegration/classes/Offer.php');

class OfferIntegrationSearchModuleFrontController extends ModuleFrontController {

	private $offer_code;

	public function __construct()
	{
		parent::__construct();
	}

	public  function initContent()
	{
		parent::initContent();

		$this->setTemplate('module:offerintegration/views/templates/front/search.tpl');
	}

	public function postProcess() {
		$show_error = false;

		if (Tools::getIsset('offer_code')) {
			$offer_code = Tools::getValue('offer_code');
			//Remove whitespaces
			$offer_code = trim($offer_code);

			$offer = Offer::getOfferForCode($offer_code);

			if ($offer != null && isset($offer[0])) {
				Tools::redirect('index.php?fc=module&module=offerintegration&controller=offer&id_oi_offer='.$offer[0]['id_oi_offer']);
			}
			$show_error = true;
		}


		$this->context->smarty->assign(array(
			'notfound' =>  $show_error
		));
	}

}