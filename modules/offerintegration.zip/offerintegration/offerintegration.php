<?php

if (!defined('_PS_VERSION_'))
    exit;

require_once(_PS_MODULE_DIR_ . '/offerintegration/controllers/admin/AdminOfferRowController.php');

class OfferIntegration extends Module {

    const CONFIGURATION_NAME = "OFFER_INTEGRATION";
    private $configuration;

    public function __construct()
    {
        $this->tabs = array(
        array(
            'name' => 'Offerte aanmaken', // One name for all langs
            'class_name' => 'AdminOffer',
            'visible' => true,
            'parent_class_name'=>'SELL',
            'position'=> 0,
            'icon'=>'featured_play_list',

        ),array(
            'name' => 'Offerte regels', // One name for all langs
            'class_name' => 'AdminOfferRow',
            'visible' => false,
            'parent_class_name'=>'SELL',
            'position'=> 0,
            'icon'=>'featured_play_list',
        ));


        $this->name = "offerintegration";
        $this->tab = 'administration';
        $this->version = '1.0.9.1';
        $this->author = 'Ijzershop';
        $this->need_instance = 1;
        $this->ps_versions_compliancy = array('min' => '1.7.0', 'max' => _PS_VERSION_);
        $this->dependencies = array();
        $this->bootstrap = true;
        $this->displayName = $this->l("Offers");
        $this->description = $this->l("Create functionality to create offers for customers with custom products. Customers can view their offer with an unique code");
        $this->confirmUninstall = $this->l("Are you sure you want to uninstall?");

        parent::__construct();

        if (!Configuration::get(OfferIntegration::CONFIGURATION_NAME))
            $this->warning = "No name" . $this->l("No name provided");
    }

    /**
     * Install offer module
     * @return bool
     */
    public function install() {

            if (Shop::isFeatureActive())
            Shop::setContext(Shop::CONTEXT_ALL);

        $createOfferTableQuery = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'oi_offer` (
            `id_oi_offer` int(11) NOT NULL AUTO_INCREMENT,
            `code` varchar(16) DEFAULT NULL,
            `name` varchar(64) DEFAULT NULL,
            `email` varchar(128) DEFAULT NULL,
            `phone` varchar(32) DEFAULT NULL,
            `message` TEXT DEFAULT NULL,
            `date_exp` DATETIME DEFAULT NULL,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_oi_offer`),
            UNIQUE KEY (`code`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;';

        $addOfferIdToProductTable = 'ALTER TABLE `'._DB_PREFIX_.'product` ADD `id_oi_offer` int(11) DEFAULT NULL;';
        $addOfferShippingToProductTable = 'ALTER TABLE `'._DB_PREFIX_.'product` ADD `oi_offer_extra_shipping` int(11) DEFAULT NULL;';

        $addOfferIdToProductShopTable = 'ALTER TABLE `'._DB_PREFIX_.'product_shop` ADD `id_oi_offer` int(11) DEFAULT NULL;';
        $addOfferShippingToProductShopTable = 'ALTER TABLE `'._DB_PREFIX_.'product_shop` ADD `oi_offer_extra_shipping` int(11) DEFAULT NULL;';

        $checkColumnIdOidOfferProduct = "SHOW COLUMNS FROM "._DB_NAME_."."._DB_PREFIX_."product WHERE FIELD =  'id_oi_offer';";
        $checkColumnIdShippingOfferProduct = "SHOW COLUMNS FROM "._DB_NAME_."."._DB_PREFIX_."product WHERE FIELD =  'oi_offer_extra_shipping';";
        $checkColumnIdOidOfferProductShop = "SHOW COLUMNS FROM "._DB_NAME_."."._DB_PREFIX_."product_shop WHERE FIELD =  'id_oi_offer';";
        $checkColumnIdShippingOfferProductShop = "SHOW COLUMNS FROM "._DB_NAME_."."._DB_PREFIX_."product_shop WHERE FIELD =  'oi_offer_extra_shipping';";


        $this->registerHook('displayAdminOrder');
        $this->registerHook('preTable');
        if (!parent::install() ||
            !Configuration::updateValue(OfferIntegration::CONFIGURATION_NAME, '') ||
            !Configuration::updateValue('OFFERINTEGRATION_LIVE_MODE', false) ||
            !$this->createCategory()){
            return false;
        }
        
        Db::getInstance()->execute($createOfferTableQuery);

        if(!Db::getInstance()->execute($checkColumnIdOidOfferProduct)){
            Db::getInstance()->execute($addOfferIdToProductTable);
        }

        if(!Db::getInstance()->execute($checkColumnIdOidOfferProductShop)){
            Db::getInstance()->execute($addOfferIdToProductShopTable);
        }

        if(!Db::getInstance()->execute($checkColumnIdShippingOfferProduct)){
            Db::getInstance()->execute($addOfferShippingToProductTable);
        }

        if(!Db::getInstance()->execute($checkColumnIdShippingOfferProductShop)){
            Db::getInstance()->execute($addOfferShippingToProductShopTable);
        }
        
        return true;
    }

    /**
     * Uninstall offer module
     * @return bool
     */
    public function uninstall()
    {

        // $dropOfferTable = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'oi_offer`';

        $checkColumnIdOidOfferProduct = "SHOW COLUMNS FROM "._DB_NAME_."."._DB_PREFIX_."product WHERE FIELD =  'id_oi_offer';";
        $checkColumnIdShippingOfferProduct = "SHOW COLUMNS FROM "._DB_NAME_."."._DB_PREFIX_."product WHERE FIELD =  'oi_offer_extra_shipping';";
        $checkColumnIdOidOfferProductShop = "SHOW COLUMNS FROM "._DB_NAME_."."._DB_PREFIX_."product_shop WHERE FIELD =  'id_oi_offer';";
        $checkColumnIdShippingProductShop = "SHOW COLUMNS FROM "._DB_NAME_."."._DB_PREFIX_."product_shop WHERE FIELD =  'oi_offer_extra_shipping';";

        $removeOfferIdToProductTable = 'ALTER TABLE `'._DB_PREFIX_.'product` DROP COLUMN `id_oi_offer`;';
        $removeOfferShippingToProductTable = 'ALTER TABLE `'._DB_PREFIX_.'product` DROP COLUMN `oi_offer_extra_shipping`;';
        $removeOfferIdToProductShopTable = 'ALTER TABLE `'._DB_PREFIX_.'product_shop` DROP COLUMN `id_oi_offer`;';
        $removeOfferShippingToProductShopTable = 'ALTER TABLE `'._DB_PREFIX_.'product_shop` DROP COLUMN `oi_offer_extra_shipping`;';

        Configuration::deleteByName('OFFERINTEGRATIONV2_LIVE_MODE');

        if (!parent::uninstall() || !Configuration::deleteByName(OfferIntegration::CONFIGURATION_NAME)) {
            return false;
        }

        // Db::getInstance()->execute($dropOfferTable);

        if(!Db::getInstance()->execute($checkColumnIdOidOfferProduct)){
            Db::getInstance()->execute($removeOfferIdToProductTable);
        }

        if(!Db::getInstance()->execute($checkColumnIdOidOfferProductShop)){
            Db::getInstance()->execute($removeOfferIdToProductShopTable);
        }

        if(!Db::getInstance()->execute($checkColumnIdShippingOfferProduct)){
            Db::getInstance()->execute($removeOfferShippingToProductTable);
        }

        if(!Db::getInstance()->execute($checkColumnIdShippingProductShop)){
            Db::getInstance()->execute($removeOfferShippingToProductShopTable);
        }

        return true;
    }


    public function createCategory() {
        $config = $this->getConfiguration();
        $check = Category::searchByName((int)Configuration::get('PS_LANG_DEFAULT'), 'Offertes', true);
        
        if (empty($check)) {
            $category = new Category();
            $category->name = [(int)Configuration::get('PS_LANG_DEFAULT') => 'Offertes'];
            $category->link_rewrite = [(int)Configuration::get('PS_LANG_DEFAULT') => 'Offerte'];
            $category->description = [(int)Configuration::get('PS_LANG_DEFAULT') => 'Speciale Categorie voor Offertes'];
            $category->active = 1;
            $category->is_root_category = 0;
            $category->position = 1;
            $category->id_parent = 1;

            if ($category->add()) {
                $config['id_category'] = (int)$category->id_category;
                $this->setConfiguration($config);
                return true;
            }
        } else {
            $category = new Category((int)$check['id_category']);
            $category->name = [(int)Configuration::get('PS_LANG_DEFAULT') => 'Offertes'];
            $category->link_rewrite = [(int)Configuration::get('PS_LANG_DEFAULT') => 'Offerte'];
            $category->description = [(int)Configuration::get('PS_LANG_DEFAULT') => 'Speciale Categorie voor Offertes'];
            $category->active = 1;
            $category->is_root_category = 0;
            $category->position = 1;
            $category->id_parent = 1;

            if ($category->update()) {
                $config['id_category'] = (int)$category->id_category;
                $this->setConfiguration($config);
            return true;
            }
        }
        return false;
    }


    public function getContent() {

        $output = null;

        if (Tools::isSubmit('submit'.$this->name)) {

            if (ValidateCore::isInt(Tools::getValue('weight')) && ValidateCore::isFloat((float)Tools::getValue('extra_shipping')) ) {

                $config = $this->getConfiguration();
                $config['weight'] = Tools::getValue('weight');
                $config['extra_shipping'] = Tools::getValue('extra_shipping');
                $this->setConfiguration($config);

                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
            else {
                $output .= $this->displayError($this->l('Invalid Configuration value'));
            }
        }
        return $output.$this->displayForm();
    }

    public function displayForm() {
        // Get default language
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        // Init Fields form array
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Settings'),
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Extra gewicht'),
                    'name' => 'weight',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Extra Verzendkosten in %, gebruik . voor decimaal'),
                    'name' => 'extra_shipping',
                    'size' => 20,
                    'required' => true
                )
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        // Language
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'submit'.$this->name;
        $helper->toolbar_btn = array(
            'save' =>
                array(
                    'desc' => $this->l('Save'),
                    'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
                        '&token='.Tools::getAdminTokenLite('AdminModules'),
                ),
            'back' => array(
                'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            )
        );

        // Load current value
        $config = $this->getConfiguration();
        $helper->fields_value['weight'] = (isset($config['weight']))? $config['weight'] : "";
        $helper->fields_value['extra_shipping'] = (isset($config['extra_shipping'])) ? $config['extra_shipping'] : "";

        return $helper->generateForm($fields_form);
    }
    public function hookDisplayAdminOrder()
    {
    }

    /**
     * Get last saved configuration
     * @return array|mixed
     */
    public function getConfiguration() {
        if ($this->configuration == null && Configuration::get(OfferIntegration::CONFIGURATION_NAME) != null) {
            $this->configuration = unserialize(Configuration::get(OfferIntegration::CONFIGURATION_NAME));
        }
        return $this->configuration;
    }

    /**
     * Save configuration array
     * @param $array
     */
    public function setConfiguration($array) {
        Configuration::updateValue(OfferIntegration::CONFIGURATION_NAME, serialize($array));
        $this->configuration = null;
    }

}