$(document).ready(function(){

    //Create generate code button
    // var div = $('input#code').parent('div');
    // $(div).removeClass('col-lg-9').addClass('col-lg-6');
    // $(div).parent('div').append('<div class="col-lg-3"><button type="button" id="generateCode">Generate code</button></div>');
    //
    // //Add logic to this button
    // $('button#generateCode').on('click', function(e){
    //     $('input#code').val(makeid())
    // });


});

function makeid() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}