# Cash payment

## About

Accept payments for your products via bank cash transfer.
