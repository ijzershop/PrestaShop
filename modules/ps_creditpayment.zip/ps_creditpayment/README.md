# Credit payment

## About

Accept payments for your products via bank credit transfer.
