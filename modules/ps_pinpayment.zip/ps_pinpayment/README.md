# Pin payment

## About

Accept payments for your products via bank pin transfer.
