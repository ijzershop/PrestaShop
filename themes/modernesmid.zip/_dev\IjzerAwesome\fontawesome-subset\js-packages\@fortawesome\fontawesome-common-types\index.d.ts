export type IconPrefix = "fas" | "fab" | "far" | "fal" | "fad";
export type IconPathData = string | string[]

export interface IconLookup {
  prefix: IconPrefix;
  // IconName is defined in the code that will be generated at build time and bundled with this file.
  iconName: IconName;
}

export interface IconDefinition extends IconLookup {
  icon: [
    number, // width
    number, // height
    string[], // ligatures
    string, // unicode
    IconPathData // svgPathData
  ];
}

export interface IconPack {
  [key: string]: IconDefinition;
}

export type IconName = 'facebook' | 
  'google' | 
  'whatsapp' | 
  'arrows-alt-h' | 
  'arrows-alt-v' | 
  'at' | 
  'ban' | 
  'book' | 
  'boxes' | 
  'check' | 
  'check-square' | 
  'chevron-down' | 
  'chevron-left' | 
  'chevron-right' | 
  'chevron-up' | 
  'circle' | 
  'clock' | 
  'cog' | 
  'comment' | 
  'cut' | 
  'database' | 
  'dolly' | 
  'edit' | 
  'ellipsis-v' | 
  'envelope' | 
  'exclamation-triangle' | 
  'eye' | 
  'eye-slash' | 
  'file-pdf' | 
  'gavel' | 
  'info-circle' | 
  'key' | 
  'list' | 
  'lock' | 
  'map-marker' | 
  'minus' | 
  'money-bill-alt' | 
  'pallet' | 
  'pencil' | 
  'percent' | 
  'phone-square-alt' | 
  'plus' | 
  'question-circle' | 
  'redo' | 
  'search' | 
  'shopping-basket' | 
  'shopping-cart' | 
  'sliders-v-square' | 
  'sync' | 
  'tag' | 
  'tags' | 
  'th-list' | 
  'times' | 
  'trash' | 
  'truck' | 
  'undo' | 
  'user' | 
  'user-circle' | 
  'user-cog' | 
  'user-secret' | 
  'warehouse' | 
  'wrench' | 
  'arrows-alt-h' | 
  'arrows-alt-v' | 
  'at' | 
  'ban' | 
  'book' | 
  'boxes' | 
  'check' | 
  'check-square' | 
  'chevron-down' | 
  'chevron-left' | 
  'chevron-right' | 
  'chevron-up' | 
  'circle' | 
  'clock' | 
  'cog' | 
  'comment' | 
  'cut' | 
  'database' | 
  'dolly' | 
  'edit' | 
  'ellipsis-v' | 
  'envelope' | 
  'exclamation-triangle' | 
  'eye' | 
  'eye-slash' | 
  'file-pdf' | 
  'gavel' | 
  'info-circle' | 
  'key' | 
  'list' | 
  'lock' | 
  'map-marker' | 
  'minus' | 
  'money-bill-alt' | 
  'pallet' | 
  'pencil' | 
  'percent' | 
  'phone-square-alt' | 
  'plus' | 
  'question-circle' | 
  'redo' | 
  'search' | 
  'shopping-basket' | 
  'shopping-cart' | 
  'sliders-v-square' | 
  'sync' | 
  'tag' | 
  'tags' | 
  'th-list' | 
  'times' | 
  'trash' | 
  'truck' | 
  'undo' | 
  'user' | 
  'user-circle' | 
  'user-cog' | 
  'user-secret' | 
  'warehouse' | 
  'wrench';
