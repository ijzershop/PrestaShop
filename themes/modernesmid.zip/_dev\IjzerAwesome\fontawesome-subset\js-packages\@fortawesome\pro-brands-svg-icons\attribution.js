console.log(`Font Awesome Pro undefined by @fontawesome - https://fontawesome.com
License - https://fontawesome.com/license (Commercial License)
`)