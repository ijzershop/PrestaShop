/*
/*
 * Custom code goes here.
 * A template should always ship with an empty custom.js
 */
$( document ).ready(function(){




function renderMoneyString(price) {
    const formatter = new Intl.NumberFormat('nl-NL', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 2,
    });
    return formatter.format(price);
  }

  $('#clearAllProductsFromCart').click(function(e){
    e.preventDefault();
    $.ajax({
      type: 'POST',
      headers: {'cache-control': 'no-cache'},
      url: prestashop.urls.pages.cart,
      async: true,
      cache: false,
      data: 'deleteAll=1&token='+prestashop.static_token+'&ajax=true',
      success: function(data) {
        window.location = prestashop.urls.base_url;
      },
    });
  });


  $('#fileUpload').on('change', function (event) {
    event.preventDefault();
    const val = $(this).val();
    if (val) {
      const name = $('#fileUpload')[0].files[0].name;
      const type = $('#fileUpload')[0].files[0].type;
      if ($.inArray(type, ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'application/dxf', 'application/zip']) !== -1) {
        $(this).siblings('label').text(name);
      } else {
        $(this).siblings('label').text(' ');
        $(this).val(null);
      }
    }
  });

  $('#printShoppingCartByEmployee').click(function(e){
    e.preventDefault();
    window.open('/index.php?controller=pdf-physical-order-slip', '_blank');
  });

  $('#printShoppingCartByEmployeeAfterCheckout').click(function (e) {
    e.preventDefault();
    const order = $(this).attr('data-order');
    window.open('/index.php?controller=pdf-physical-order-slip?id_order='+ order, '_blank');
  });

  $('#printShoppingCartOnCreditByEmployeeAfterCheckout').click(function (e) {
    e.preventDefault();
    const order = $(this).attr('data-order');
    window.open('/index.php?controller=pdf-physical-on-credit-order-slip?id_order='+ order, '_blank');
  });


  $('.user-info').on('click', function (event) {
    event.stopPropagation();
    const clickedBtn = $(this).find('.dropdown');
    if (clickedBtn.hasClass('d-block')) {
      clickedBtn.removeClass('d-block');
      clickedBtn.find('.dropdown-toggle').attr('aria-expanded', 'false');
      clickedBtn.find('.dropdown-menu').removeClass('d-block');
    } else {
      clickedBtn.addClass('d-block');
      clickedBtn.find('.dropdown-toggle').attr('aria-expanded', 'true');
      clickedBtn.find('.dropdown-menu').addClass('d-block');
    }
  });

  // footer-block-top accordion
  $(document.body).on('click', '.title_block', function (event) {
    event.preventDefault();
    $this = $(this);
    $this.find('.opener > svg.fa-plus').toggleClass('d-sm-none').toggleClass('d-none');
    $this.find('.opener > svg.fa-minus').toggleClass('d-sm-none').toggleClass('d-none');
    $this.siblings('.footer_block_content').toggleClass('d-sm-block d-sm-none').toggleClass('d-none d-block');
  });

  // Sidebar menu open close submenu
  $('button.arrows').on('click', function (event) {
    const $this = $(this);
    const target = $this.attr('data-target');
    $this.children('.fa-plus').toggleClass('d-none');
    $this.children('.fa-minus').toggleClass('d-none');
    $this.siblings('.collapse').toggleClass('show');
  });

  $(document.body).on('click', '.shoppingcart-list-block > .menu-title > a#shoppingcart-chevron-close, .shoppingcart-list-block > .menu-title', function(event){
    event.preventDefault();
    $('html').css({
      'overflow-y': 'scroll',
      'overflow-x': 'hidden',
    });
    $('#shoppingcart-list-items').css({
      'overflow-x': 'hidden',
      'overflow-y': 'hidden',
    });
    $('#shoppingcart-side-panel').addClass('d-none');
    $('.cart_body').css({
      opacity: '0',
      'z-index': '-1',
    });
  });
  $(document.body).on('click', '#my-account-link', function(event){
    event.stopImmediatePropagation();
  });

  function calcShoppingCartListItemsColumnHeight(extraPadding) {
    var titleHeight = 0;
    if (document.getElementById('shoppingcart-list-title')) {
      titleHeight = document.getElementById('shoppingcart-list-title').clientHeight;
    }

    var headerHeight = 0;
    if (document.getElementById('shoppingcart-list-header-totals')) {
      headerHeight = document.getElementById('shoppingcart-list-header-totals').clientHeight;
    }

    var footerHeight = 0;
    if (document.getElementById('shoppingcart-list-footer-totals')) {
      footerHeight = document.getElementById('shoppingcart-list-footer-totals').clientHeight;
    }

    const totalHeight = titleHeight + headerHeight + footerHeight + extraPadding;
    const value = 'calc(100vh - '+ totalHeight+'px)';
    return value;
  }

  $(document).on('click','div.ajax_cart_bag .top-header-shoppingcart, .nav-link.top-header-shoppingcart', function(event){
    event.preventDefault();
    if ($('#shoppingcart-side-panel').hasClass('d-none')) {
      $('html').css({
        'overflow-x': 'hidden',
        'overflow-y': 'hidden',
      });
      if ($('#main-menu-bar').hasClass('is-sticky')) {
        var paddingTop = $('#main-menu-bar').height();
      } else {
        var paddingTop = 0;
      }
      $('#shoppingcart-side-panel').css('padding-top', paddingTop);
      $('#shoppingcart-side-panel').removeClass('d-none');

      const listHeight = calcShoppingCartListItemsColumnHeight(paddingTop);
      // console.log([paddingTop,parseInt(paddingTop), listHeight]);
      document.getElementById('shoppingcart-list-items').style.height = listHeight;

      var ulClientHeight = 0;
      if (document.getElementsByClassName('small_cart_product_list').length > 0 && document.getElementsByClassName('small_cart_product_list')[0]) {
        ulClientHeight = document.getElementsByClassName('small_cart_product_list')[0].clientHeight + 15;
      }
      const clientHeight = document.getElementById('shoppingcart-list-items').clientHeight;
      if (ulClientHeight > clientHeight) {
        document.getElementById('shoppingcart-list-items').style.overflowY = 'scroll';
        document.getElementById('shoppingcart-list-items').style.overflowX = 'hidden';
      } else {
        document.getElementById('shoppingcart-list-items').style.overflowY = 'hidden';
        document.getElementById('shoppingcart-list-items').style.overflowX = 'hidden';
      }
      $('.cart_body').css({
        opacity: '1',
        'z-index': '5',
      });
    } else {
      $('html').css({
        'overflow-x': 'hidden',
        'overflow-y': 'scroll',
      });
      document.getElementById('shoppingcart-list-items').style.overflowX = 'hidden';
      document.getElementById('shoppingcart-list-items').style.overflowY = 'hidden';
      $('#shoppingcart-side-panel').addClass('d-none');
      $('.cart_body').css({
        opacity: '0',
        'z-index': '-1',
      });
    }
  });

  $(window).resize(function(){
    if (!$('#shoppingcart-side-panel').hasClass('d-none')) {
      $('#shoppingcart-list-items').css({
        'overflow-x': 'hidden',
        'overflow-y': 'scroll',
      });
      var ulClientHeight = 0;
      if (document.getElementsByClassName('small_cart_product_list').length > 0 && document.getElementsByClassName('small_cart_product_list')[0]) {
        ulClientHeight = document.getElementsByClassName('small_cart_product_list')[0].clientHeight + 15;
      }
      var listHeight = 0;
      if (document.getElementById('shoppingcart-list-items') !== null && document.getElementById('shoppingcart-list-items')[0]) {
        listHeight = document.getElementById('shoppingcart-list-items').clientHeight;
      }

      if (listHeight < ulClientHeight) {
        $('#shoppingcart-list-items').css({
          'overflow-x': 'hidden',
          'overflow-y': 'scroll',
        });
      } else {
        $('#shoppingcart-list-items').css({
          'overflow-x': 'hidden',
          'overflow-y': 'hidden',
        });
      }
    }
  });

  $('#menu-side-panel > .menu-title > a.menu-chevron-close').on('click', function(event){
    event.preventDefault();
    if (!$('#navbar-menu-chevron').hasClass('d-none')) {
      $('#navbar-menu-chevron').addClass('d-none');
      $('#side-panel-menu-block').addClass('d-none');
    }
    if (!$('#navbar-search-chevron').hasClass('d-none')) {
      $('#navbar-search-chevron').addClass('d-none');
      $('#side-panel-search-block').addClass('d-none');
    }
    $('.menu_body > #menu-side-panel').toggleClass('d-none');
    $('.cart_body').css({
      opacity: '0',
      'z-index': '-1',
    });

    $('html').css({
      'overflow-x': 'hidden',
      'overflow-y': 'scroll',
    });
  });

  $('.navbar-toggler-icon').on('click', function(event){
    event.preventDefault();
    $('#navbar-menu-chevron').toggleClass('d-none');
    $('#side-panel-menu-block').toggleClass('d-none');
    if ($('#main-menu-bar').hasClass('is-sticky')) {
      var paddingHeight = 'calc(100vh - 48px - '+$('#main-menu-bar').height()+')';
      var paddingTop = '40px';
    } else {
      var paddingHeight = 'calc(100vh - 48px)';
      var paddingTop = '0px';
    }

    $('#side-panel-menu-block').css('height', paddingHeight);
    $('#menu-side-panel').css('top', paddingTop);
    $('#menu-side-panel').toggleClass('d-none');

    if ($('#menu-side-panel').hasClass('d-none')) {
      $('.cart_body').css({
        opacity: '0',
        'z-index': '-1',
      });

      $('html').css({
        'overflow-x': 'hidden',
        'overflow-y': 'scroll',
      });
    } else {
      $('html').css({
        'overflow-x': 'hidden',
        'overflow-y': 'hidden',
      });
      $('.cart_body').css({
        opacity: '1',
        'z-index': '5',
      });
    }
  });

  $('.navbar-search-icon').on('click', function(event){
    event.preventDefault();
    $('#navbar-search-chevron').toggleClass('d-none');
    $('#side-panel-search-block').toggleClass('d-none');
    if ($('#main-menu-bar').hasClass('is-sticky')) {
      var paddingHeight = 'calc(100vh - 48px - '+$('#main-menu-bar').height()+')';
      var paddingTop = '40px';
    } else {
      var paddingHeight = 'calc(100vh - 48px)';
      var paddingTop = '0px';
    }

    $('#side-panel-search-block').css('height', paddingHeight);
    $('#menu-side-panel').css('top', paddingTop);
    $('#menu-side-panel').toggleClass('d-none');

    if ($('#menu-side-panel').hasClass('d-none')) {
      $('.cart_body').css({
        opacity: '0',
        'z-index': '-1',
      });

      $('html').css({
        'overflow-x': 'hidden',
        'overflow-y': 'scroll',
      });
    } else {
      $('html').css({
        'overflow-x': 'hidden',
        'overflow-y': 'hidden',
      });
      $('.cart_body').css({
        opacity: '1',
        'z-index': '5',
      });
    }
  });

  $(document.body).on('click', '.cart_details_toggle', function (event) {
    const checked = $(this).prop('checked');
    if (checked) {
      $('.cart_price_details').show();
    } else {
      $('.cart_price_details').hide();
    }
    const listHeight = calcShoppingCartListItemsColumnHeight();
    document.getElementById('shoppingcart-list-items').style.height = listHeight;
  });

  $('#search_filters .title').on('click', function (event) {
    event.stopPropagation();
    const clickedElem = $(this);
    const target = clickedElem.attr('data-target');
    clickedElem.find('svg.add').toggleClass('d-none');
    clickedElem.find('svg.remove').toggleClass('d-none');
    $('ul'+target).toggleClass('collapse show');
  });

  $('#search_filters .custom-control-input').on('click', function (event) {
    event.preventDefault();
    const target = $(this).attr('data-search-url');
    window.location = target;
  });

  $('#search_filters .js-search-filters-clear-all').on('click', function (event) {
    event.preventDefault();
    const target = $(this).attr('data-search-url');
    window.location = target;
  });

  window.onclick = function (event) {
    if ($('.cart_body').css('opacity') == 1) {
      if (!$(event.target).hasClass('shoppingcart-ellipsis')
        && !$(event.target).hasClass('cart_product_item_row')
        && !$(event.target).hasClass('shoppingcart-dropdown-menu')
        && !$(event.target).hasClass('dropdown-item')
      ) {
        // close all shoppingcart dropdowns
        $('.shoppingcart-ellipsis').removeClass('show');
        $('.shoppingcart-dropdown-menu').hide();
      }
    }
  };

  $(document.body).on('click', '.cart_product_item_row', function (event) {
    if (!$(event.target).hasClass('dropdown-item') && !$(event.target).hasClass('cart_quantity') && !$(event.target).hasClass('updateCartBurron') && !$(event.target).hasClass('fa-check') && !$(event.target).hasClass('dp_url')) {
      event.stopPropagation();
      const elem = $(this).find('.dropdown-menu');
      if (elem.is(':visible')) {
        $('.shoppingcart-dropdown-menu').hide();
      } else {
        $('.shoppingcart-dropdown-menu').hide();
        elem.toggle();
      }
    }
  });

// $(document.body).on('click','a.updateCartBurron svg', function (event) {
//         event.stopImmediatePropagation();
//         $(this).parents('a.updateCartBurron').trigger('click');
//       });

      $(document.body).on('click','a.updateCartBurron', function (event) {
        const qty = parseInt($(this).parents('.qty_wrap').find('input').val());
        const current = parseInt($(this).attr('data-current-value'));
        const product = $(this).attr('data-product-id');
        const cust = $(this).attr('data-id-customization');
        const attr = $(this).attr('data-id-product-attribute');
        const $input = $(this).parents('.qty_wrap').find('input');
        if (typeof $input.attr('data-stock_quantity') !== undefined && parseInt($input.attr('data-stock_quantity')) < qty && parseInt($input.attr('data-stock_quantity')) !== -1) {
          $input.val($input.attr('data-stock_quantity'));
          $input.closest('.qty_wrap').find('.max_quantity').toggleClass('d-none');
          event.stopPropagation();
          return false;
        }
        var op = 'up';
        if (qty > current) { // add
          var quantity_wanted = qty - current;
        } else { // remove
          var quantity_wanted = current - qty;
          var op = 'down';
        }
        if (quantity_wanted === 0) {
          return false;
        }
        const link = $(this).attr('data-update-url')+'&add=1&action=update&id_product='+product+'&id_product_attribute='+attr+'&id_customization='+cust+'&qty='+quantity_wanted+'&op='+op+'&ajax=1';
        $.ajax({
          url: link,
          type: 'POST',
          success: function(json) {
            const response = JSON.parse(json);
            if(!response.hasError){
              // Display any messages
              prestashop.emit('updateCart', {
                reason: response,
              });
            } else {
              $input.siblings('.error-msg').remove();
              $input.siblings('.input-group-append').after('<small class="error-msg text-danger">'+response.errors[0]+'</small>');

            }
          },
        }).done(function (e) {
          $(this).parents('li').find('.qty_wrap').hide();
          $(this).parents('li').find('.customized_wrap').show();
        });
      });


  $(document.body).on('click', '.shoppingcart-dropdown-menu a.dropdown-item', function (event) {
    const elem = $(this);
    if ($(event.target).hasClass('changeCartProductQty')) {
      $(elem).parents('li').find('.qty_wrap').show();
      $(elem).parents('li').find('.customized_wrap').hide();

      $(elem).parents('.dropdown-menu').toggle();
    } else {
      event.stopImmediatePropagation();
      $.ajax({
        url: $(event.target).attr('data-href'),
        type: 'POST',
        data: {
          ajax: 1,
          action: 'update',
        },
        success: function(json) {
          const response = JSON.parse(json);
          // Display any messages
          prestashop.emit('updateCart', {
            reason: response,
          });
        },
      }).done(function(e){
        // $(this).parents('li').find('.qty_wrap').hide();
        // $(this).parents('li').find('.customized_wrap').show();
      });
    }
  });

  // show hide password at login
  $('button[data-action="show-password"]').on('click', function () {
    const elm = $(this).closest('.input-group').children('input.js-visible-password');
    if (elm.attr('type') === 'password') {
      elm.attr('type', 'text');
      $(this).html($(this).data('textHide')).text();
    } else {
      elm.attr('type', 'password');
      $(this).html($(this).data('textShow')).text();
    }
  });

  // sticky navbar
  const stickyToggle = function (sticky, stickyWrapper, scrollElement) {
    const stickyHeight = sticky.outerHeight();
    const stickyTop = stickyWrapper.offset().top;
    if (scrollElement.scrollTop() >= stickyTop) {
      stickyWrapper.height(stickyHeight);
      sticky.addClass('is-sticky');
    } else {
      sticky.removeClass('is-sticky');
      stickyWrapper.height('auto');
    }
  };

  $('[data-toggle="sticky-onscroll"]').each(function () {
    const sticky = $(this);
    const stickyWrapper = $('<div>').addClass('sticky-wrapper'); // insert hidden element to maintain actual top offset on page
    sticky.before(stickyWrapper);
    sticky.addClass('sticky');

    // Scroll & resize events
    $(window).on('scroll.sticky-onscroll resize.sticky-onscroll', function () {
      stickyToggle(sticky, stickyWrapper, $(this));
    });
    // On page load
    stickyToggle(sticky, stickyWrapper, $(window));
  });

  // info icon open close
  $(document).on('click', '.info-icon-with-showhide', function (event) {
    event.preventDefault();
    const id = $(this).attr('data-id');
    $('#'+id).toggle();
  });

  $(document).on('change', 'input[name=qty]', function (event) {
    event.preventDefault();


    const quantity = $(this).val();
    const product_id = $(this).attr('data-product-id');
    const data = {
      'product_id':product_id,
      'quantity':quantity,
    };

    $.ajax({
      url: '/module/sawandcutmodule/ajax',
      type: 'GET',
      data: 'method=calculatestaffel&data='+JSON.stringify(data)+'&ajax=true',
      dataType: 'json',
      success: function(json) {
        if (json.product_price_incl_w_reduction_w_tax !== json.product_price_incl) {
          $('.regular-price[data-product-id="'+ json.id_product +'"]').html(renderMoneyString(json.product_price_incl)+'  ');
          $('.inclusive-price[data-product-id="'+ json.id_product +'"]').html(renderMoneyString(json.product_price_incl_w_reduction_w_tax)+' Incl. btw');
          $('.exclusive-price[data-product-id="'+ json.id_product +'"]').html(renderMoneyString(json.product_price_incl_w_reduction)+' Excl. btw');

          if ($('.discount').length > 0) {
            const discountBlock = '<span class="discount discount-amount">Bespaar '+ json.reduction_percentage * 100 +'% korting <br>vanaf '+json.reduction_label+' stuks</span>';
            $('.discount').html(discountBlock);
          }
        } else {
          $('.regular-price[data-product-id="'+ json.id_product +'"]').html('');
          $('.inclusive-price[data-product-id="'+ json.id_product +'"]').html(renderMoneyString(json.product_price_incl_w_reduction_w_tax)+' Incl. btw');
          $('.exclusive-price[data-product-id="'+ json.id_product +'"]').html(renderMoneyString(json.product_price_incl_w_reduction)+' Excl. btw');
        }
      },
      error: function(json) {
        // console.log('Error occured during validation, pleae contact administrator.');
      },
    });
  });

  $(document).on('change', '.js-cart-line-product-quantity', function (event) {
    const current = parseInt(event.currentTarget.getAttribute('data-current-value'));
    const $input = $(this);
    const value = parseInt(event.currentTarget.value);
    const update = event.currentTarget.getAttribute('data-update-url');
    if (parseInt($input.attr('max')) < value) {
      $input.val($input.attr('max'));
      $input.closest('.row').find('.max_quantity').toggleClass('d-none');
      event.stopPropagation();
      $input.trigger('change');
      return false;
    }


    if (current < value) {
      var newValue = value - current;
      window.location = update+'&qty='+newValue+'&op=up';
    } else {
      var newValue = current - value;
      window.location = update+'&qty='+newValue+'&op=down';
    }
  });

  const updateHeaderCart = function (cart) {
    $('#header-cart-vat').text(renderMoneyString(cart.subtotals.tax.amount));
    $('#header-cart-total').text(renderMoneyString(cart.totals.total.amount));

    $('shoppingcart-header-total-price').text(renderMoneyString(cart.totals.total.amount));

    var countLabel = 'Product ';
    if (parseInt(cart.products_count) > 1) {
      const countlabel = 'Producten ';
    } else {
      var countLabel = 'Product ';
    }
    $('#header-cart-total-products').text(countLabel+'('+cart.products_count+')');
    $('.top-header-shoppingcart .amount_circle').text(cart.products_count);

    var totalForAllProducts = 0;
    var productsTotal = 0;
    for (var i = cart.products.length - 1; i >= 0; i--) {
      productsTotal = cart.products[i].price_with_reduction_without_tax * cart.products[i].quantity;
      totalForAllProducts += productsTotal;
    }

    if (parseInt(productsTotal) === 0) {
      $('.top-header-shoppingcart').find('[data-fa-i2svg]').removeClass('fas fa-shopping-cart').addClass('fad fa-shopping-cart');
    } else {
      $('.top-header-shoppingcart').find('[data-fa-i2svg]').removeClass('fad fa-shopping-cart').addClass('fas fa-shopping-cart');
    }
    $('#header-cart-subtotal').text(renderMoneyString(totalForAllProducts));
    $('#header-cart-shipping').text(renderMoneyString(cart.subtotals.shipping.amount_without_tax));

    // if (totalForAllProducts === 0 || totalForAllProducts >= parseFloat($('#header-cart-small-order-fee').attr('data-amount'))) {
    //   $('#header-cart-vat').css("border-bottom", "2px solid #777777");
    //   $('#header-cart-small-order-fee').hide();
    // } else {
    //   $('#header-cart-vat').css("border-bottom", "none");
    //   $('#header-cart-small-order-fee').show();
    // }
    $('.info-icon-with-showhide').on('click', function (event) {
      event.preventDefault();
      const id = $(this).attr('data-id');
      $('#'+id).toggle();
    });
  };

  function updateSideBarCart(cart) {
    if (!cart) {
      return false;
    }
    return true;
  }

  prestashop.on('updateCart', function(event){
    prestashop.cart = event.reason.cart;
    if (prestashop.cart) {
      updateHeaderCart(prestashop.cart);
    } else {
      updateHeaderCart(prestashop.summaryDetails);
    }

    const getCartViewUrl = $('.js-cart').data('refresh-url');
    if (!getCartViewUrl) {
      return;
    }

    var requestData = {};
    if (event && event.reason) {
      if (event.reason.idProductAttribute !== undefined) {
        requestData = {
          id_product_attribute: event.reason.idProductAttribute,
          id_product: event.reason.idProduct,
        };
      } else {
        requestData = {
          id_product_attribute: event.reason.id_product_attribute,
          id_product: event.reason.id_product,
        };
      }
    }
    $.post(getCartViewUrl, requestData).then(function(resp){
      const product = $('a[data-product-id="'+requestData.id_product+'"]');
      showFlyimgImage(product);
      if (resp.cart_detailed_totals !== undefined) {
        $('.cart-detailed-totals').replaceWith(resp.cart_detailed_totals);
        $('.cart-summary-items-subtotal').replaceWith(resp.cart_summary_items_subtotal);
        $('.cart-summary-subtotals-container').replaceWith(resp.cart_summary_subtotals_container);
        $('.cart-summary-totals').replaceWith(resp.cart_summary_totals);
        $('.cart-detailed-actions').replaceWith(resp.cart_detailed_actions);
        $('.cart-voucher').replaceWith(resp.cart_voucher);
        $('.cart-overview').replaceWith(resp.cart_detailed);

        $('#product_customization_id').val(0);

        $('.js-cart-line-product-quantity').each(function(index, input){
          const $input = $(input);
          $input.attr('value', $input.val());
        });

        if ($('.js-cart-payment-step-refresh').length) {
          // we get the refresh flag : on payment step we need to refresh page to be sure
          // amount is correctly updated on payment modules
          refreshCheckoutPage();
        }
      } else { // normal refresh cart
        $('#shoppingcart-side-panel').html(resp.modal);
        $('.cart_details_toggle').on('click', function (event) {
          const checked = $(this).prop('checked');
          if (checked) {
            $('.cart_price_details').show();
          } else {
            $('.cart_price_details').hide();
          }
          const listHeight = calcShoppingCartListItemsColumnHeight();
          document.getElementById('shoppingcart-list-items').style.height = listHeight;
        });
      }

      prestashop.emit('updatedCart', {
        eventType: 'updateCart',
        resp: resp,
      });
    }).fail(function(resp){
      prestashop.emit('handleError', {
        eventType: 'updateCart',
        resp: resp,
      });
    });

    $('.info-icon-with-showhide').on('click', function (event) {
      event.preventDefault();
      const id = $(this).attr('data-id');
      $('#'+id).toggle();
    });
  });
  $('body').on('focusin', '[name="qty"]', function (event) {
    event.preventDefault();
    $(this).val(null);
  });
  // add to cart buttons actions
  $('body').on('click', '[data-button-action="add-to-cart"]', function (event) {
    event.preventDefault();
    $(this).addClass('active');
    const product_id = $(this).attr('data-product-id');
    const max_quantity = parseInt($('#quantity_wanted_'+product_id).attr('max'));
    var quantity = parseInt($('#quantity_wanted_'+product_id).val());

    if (quantity > max_quantity) {
      $('#quantity_wanted_'+product_id).val(max_quantity);
      event.stopPropagation();
      return false;
    }

    if (isNaN(quantity)) {
      quantity = 1;
    }

    const product_customization_id = $('#quantity_wanted_'+product_id).attr('data-product-customization');
    const clickedHref = $(this).attr('href');
    const icon = $(this).find('svg');
    icon.addClass('fa-sync fa-spin');

    if ($('#quantity_wanted_'+product_id).val() > $('[data-stock]').data('stock') && $('[data-allow-oosp]').data('allow-oosp').length === 0) {
      $('[data-button-action="add-to-cart"]').attr('disabled', 'disabled');
    } else {
      const clickedHref = $(this).attr('href');


      const query = {
        id_customization: product_customization_id,
        id_product: product_id,
        add: 1,
        qty: quantity,
        action: 'update',
      };

      $.ajax({
        url: clickedHref+'&id_customization='+product_customization_id+'&id_product='+product_id+'&add=1&qty='+quantity+'&action=update',
        type: 'POST',
        dataType: 'json',
        data: query,
      })
        .done(function(resp){
          $('svg[data-product-id="'+product_id+'"]').removeClass('fa-spin');
          $('svg[data-product-id="'+product_id+'"]').removeClass('fa-sync');
          $('a.add-to-cart[data-product-id="'+product_id+'"]').removeClass('active');
          $('svg[data-product-id="'+product_id+'"]').addClass('fa-shopping-cart');
          if (resp.hasError === true) {
            return false;
          }

          prestashop.emit('updateCart', {
            reason: {
              idProduct: resp.id_product,
              idProductAttribute: resp.id_product_attribute,
              idCustomization: resp.id_customization,
              linkAction: 'add-to-cart',
              cart: resp.cart,
            },
            resp:resp,
          });
        })
        .fail(function(resp){
          prestashop.emit('handleError', {
            eventType: 'addProductToCart',
            resp:resp,
          });
        });
    }
  });

  function fetchCitties(addresses) {
    const citties = [];
    for (var i = 0; i < addresses.length; i++) {
      citties.push({
        text: addresses[i].city,
        value: addresses[i].city,
      });
    }
    return citties;
  }

  // address forms
  var timeout;
  const delay = 500;
  //Api address check shipping
  $(document.body).on('keyup change input :-webkit-autofill', '#customer_address_form [name="postcode"], #customer_address_form [name="house_number"], #customer_address_form [name="address1"], #customer_address_form [name="house_number_extension"]', function(event){
    event.preventDefault();

    if (event.currentTarget.name === 'postcode') {
      if (event.currentTarget.value.length > 4) {
        $('[name="postcode"]').val(event.currentTarget.value.replace(/(\d{4})/g, '$1 ').replace(/  +/g, ' '));
      }
    }

    if (timeout) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(function(){
      const postcode = $('[name="postcode"]').val().replace(' ', '');
      const houseNumber = $('[name="house_number"]').val().replace(' ', '');
      const extension = $('[name="house_number_extension"]').val().replace(' ', '');
      // const street = encodeURIComponent($('[name="address1"]').val());
      const street = '';
      const id_country = $('[name="id_country"]').val().replace(' ', '');
      if (postcode.length > 3 || houseNumber.length > 0) {
        validateAddressApi(postcode, street, houseNumber, extension, id_country);
      }
      return false;
    }, delay);
  });

  // //Api address check payment
  // $(document.body).on('keyup change input :-webkit-autofill', '#customer_address_form [name="shipping_address[postcode]"], #customer_address_form [name="shipping_address[house_number]"], #customer_address_form [name="shipping_address[address1]"], #customer_address_form [name="shipping_address[house_number_extension]"]', function(event){
  //   event.preventDefault();
  //
  //   if (event.currentTarget.name === 'postcode') {
  //     if (event.currentTarget.value.length > 4) {
  //       $('[name="shipping_address[postcode]"]').val(event.currentTarget.value.replace(/(\d{4})/g, '$1 ').replace(/  +/g, ' '));
  //     }
  //   }
  //
  //   if (timeout) {
  //     clearTimeout(timeout);
  //   }
  //   timeout = setTimeout(function(){
  //     const postcode = $('[name="shipping_address[postcode]"]').val().replace(' ', '');
  //     const houseNumber = $('[name="shipping_address[house_number]"]').val().replace(' ', '');
  //     const extension = $('[name="shipping_address[house_number_extension]"]').val().replace(' ', '');
  //     // const street = encodeURIComponent($('[name="shipping_address[address1]"]').val());
  //     const street = '';
  //     const id_country = $('[name="shipping_address[id_country]"]').val().replace(' ', '');
  //     if (postcode.length > 3 || houseNumber.length > 0) {
  //       validateAddressApi(postcode, street, houseNumber, extension, id_country, "shipping_address");
  //     }
  //     return false;
  //   }, delay);
  // });

  $(document.body).on('click', '.selectStreetAutoFill', function (event) {
    event.preventDefault();
    const streetName = $(this).text();
    $('[name="address1"]').val(streetName).removeClass('is-invalid').addClass('was-validated is-valid');
    $('#suggesstion-box-street').html('');
  });



  function validateAddressApi(postcode, street, houseNumber, extension, country) {
    var postC = postcode.replace(' ', '');
    var houseN = houseNumber.replace(' ', '');
    if (extension) {
      extension = extension.replace(' ', '');
    }

    $.ajax({
      url: postcodeApiUrl,
      type: 'GET',
      dataType: 'json',
      data: {
        postcode:postcode,
        houseNumber:houseNumber,
        extension:extension,
        street:street,
        id_country: country,
        ajax: true,
      },
    })
      .done(function(e){
        var isValidForConfirm = false;
        $('.address-error-msg').text(null);

        if (e.valid != false && e.address.length > 0 && e.address[0].hasOwnProperty('nl_sixpp')) { // is een nederlands adres

          $('[name="id_country"]').removeClass('is-invalid').addClass('was-validated is-valid');
          $('[name="postcode"]').removeClass('is-invalid').addClass('was-validated is-valid');
          $('[name="city"]').removeClass('is-invalid').addClass('was-validated is-valid');

          if (e.address[0].city != undefined) {
            $('[name="city"]').val(e.address[0].city).removeClass('is-invalid').addClass('was-validated is-valid');
          }

          if (e.address[0].street != 'undefined') {
            $('[name="address1"]').val(e.address[0].street).removeClass('is-invalid').addClass('was-validated is-valid');
            isValidForConfirm = true;
          } else {
            $('[name="address1"]').val('').removeClass('was-validated is-valid').addClass('is-invalid');
            isValidForConfirm = false;
          }

          if ($('[name="house_number"]').val().length > 0) {
            $('[name="house_number"]').removeClass('is-invalid').addClass('was-validated is-valid');
            $('[name="house_number_extension"]').removeClass('is-invalid').addClass('was-validated is-valid');
            isValidForConfirm = true;
          } else {
            $('[name="house_number"]').addClass('is-invalid');
            $('[name="house_number_extension"]').addClass('is-invalid');
            isValidForConfirm = false;
          }


        } else if (e.valid != false && e.address.length > 0 && e.address[0].hasOwnProperty('be_fourpp')) {

          if (e.address[0].city_nl != undefined) {
            $('[name="city"]').val(e.address[0].city_nl).removeClass('is-invalid').addClass('was-validated is-valid');
          }
          $('[name="address1"]').val(e.address[0].street_nl).removeClass('is-invalid').removeClass('was-validated is-valid');
          isValidForConfirm = true;

          // is een belgisch adres
          $('[name="postcode"]').removeClass('is-invalid').removeClass('was-validated is-valid');

          $('[name="id_country"]').removeClass('is-invalid').addClass('was-validated is-valid');
          $('[name="house_number"]').removeClass('is-invalid').removeClass('was-validated is-valid');

          $('[name="house_number_extension"]').removeClass('is-invalid').removeClass('was-validated is-valid');


        }  else if (e.valid != false && e.address.length == 1 && e.address[0].hasOwnProperty('street_nl')) {


          $('[name="address1"]').val(e.address[0].street_nl).removeClass('is-invalid').addClass('was-validated is-valid');
          if ($('[name="house_number"]').val().length > 0) {
            $('[name="house_number"]').removeClass('is-invalid').addClass('was-validated is-valid');
            $('[name="house_number_extension"]').removeClass('is-invalid').addClass('was-validated is-valid');
            isValidForConfirm = true;
          } else {
            $('[name="house_number"]').addClass('is-invalid');

            $('[name="house_number_extension"]').addClass('is-invalid');
            isValidForConfirm = false;
          }
          // is een belgisch adres
        } else if (e.valid != false && e.address.length > 1) {
          isValidForConfirm = false;
          var htmlList = '<ul>';
          for (var i = 0; i < e.address.length; i++) {
            htmlList += '<li class="selectStreetAutoFill">'+e.address[i].street_nl+'</li>';
          }
          htmlList += '</ul>';
          $('#suggesstion-box-street').html(htmlList);
          // is een belgisch adres
        } else {
          if (e.msg == 'Fetching address failed') {
            $('[name="address1"]').val('').addClass('is-invalid').removeClass('was-validated is-valid');
            isValidForConfirm = false;
          }

          if(e.msg !== null && e.msg.hasOwnProperty('field') && e.msg.field !== undefined){
            isValidForConfirm = false;
          }
          $('[name="postcode"]').removeClass('is-invalid').addClass('was-validated is-valid');

          $('[name="house_number"]').removeClass('is-invalid').removeClass('was-validated is-valid');
          $('[name="house_number_extension"]').removeClass('is-invalid').removeClass('was-validated is-valid');
          $('[name="address1"]').removeClass('is-invalid').removeClass('was-validated is-valid');

          $('[name="id_country"]').removeClass('is-invalid').addClass('was-validated is-valid');

          $('[name="city"]').removeClass('is-invalid').addClass('is-valid');

          if (e.msg !== 'ok') {
            if (e.msg !== null && e.msg.hasOwnProperty('field') &&  e.msg.field) {
              if (e.msg.field === 'house_number') {
                $('[name="house_number_extension"]').removeClass('is-valid').addClass('is-invalid');
                $('[name="address1"]').removeClass('is-valid').addClass('is-invalid');
                $('[name="address1"]').siblings('.address-error-msg').text(null).text('Het huisnummer kan niet gevonden worden mogelijk is de straat onjuist');
              }
              $('[name="'+ e.msg.field + '"]').removeClass('is-valid').addClass('is-invalid');
              $('[name="'+ e.msg.field + '"]').siblings('.address-error-msg').text(null).text(e.msg.msg);
              isValidForConfirm = false;
            }
          } else if (e.msg === 'ok' && e.valid) {
            $('[name="id_country"]').removeClass('is-invalid').addClass('was-validated is-valid');
            $('[name="postcode"]').removeClass('is-invalid').addClass('was-validated is-valid');

            if ($('[name="house_number"]').val().length > 0) {
              $('[name="house_number"]').removeClass('is-invalid').addClass('was-validated is-valid');
              $('[name="house_number_extension"]').removeClass('is-invalid').addClass('was-validated is-valid');
            } else {
              $('[name="house_number"]').addClass('is-invalid');
              $('[name="house_number_extension"]').addClass('is-invalid');
            }
            $('[name="city"]').removeClass('is-invalid').addClass('was-validated is-valid');
            $('[name="address1"]').removeClass('is-invalid').addClass('was-validated is-valid');
            isValidForConfirm = true;
          }
        }

        if(isValidForConfirm){
          disEnConfirmButtonAddress(false);

          $('[name="id_country"]').removeClass('is-invalid').addClass('was-validated is-valid');
          $('[name="postcode"]').removeClass('is-invalid').addClass('was-validated is-valid');
          $('[name="city"]').removeClass('is-invalid').addClass('was-validated is-valid');
          $('[name="id_country"]').removeClass('is-invalid').addClass('was-validated is-valid');
        } else {
          disEnConfirmButtonAddress(true);

          $('[name="id_country"]').addClass('is-invalid').removeClass('was-validated is-valid');
          $('[name="postcode"]').addClass('is-invalid').removeClass('was-validated is-valid');
          $('[name="city"]').addClass('is-invalid').removeClass('was-validated is-valid');
          $('[name="id_country"]').addClass('is-invalid').removeClass('was-validated is-valid');
        }
      })
      .fail(function(e){
        disEnConfirmButtonAddress(true);
        $('[name="address1"]').addClass('is-invalid').removeClass('was-validated is-valid');
        $('[name="house_number"]').addClass('is-invalid').removeClass('was-validated is-valid');
        $('[name="house_number_extension"]').addClass('is-invalid').removeClass('was-validated is-valid');
        $('[name="id_country"]').addClass('is-invalid').removeClass('was-validated is-valid');
        $('[name="postcode"]').addClass('is-invalid').removeClass('was-validated is-valid');
        $('[name="city"]').addClass('is-invalid').removeClass('was-validated is-valid');
        $('[name="id_country"]').addClass('is-invalid').removeClass('was-validated is-valid');
      });
  }


  function disEnConfirmButtonAddress(disable){
    // console.log(disable);
    if(disable){
      $('button[name="confirm-addresses"]').attr('disabled',true);
    } else {
      $('button[name="confirm-addresses"]').attr('disabled',false);
    }
  }


  $('.delivery-option input[type=radio]').on('click', function (event) {
    if (!$(this).hasClass('add2order') && (parseInt($(this).val()) == shoppingcart.add2order_carrier)) {
      $('#added_to_order').val($(this).attr('data-order-reference'));
    }
    if (!$(this).hasClass('add2order') && (parseInt($(this).val()) != shoppingcart.add2order_carrier)) {
      $('#added_to_order').val(null);
    }

    if ($(this).hasClass('add2order')) {
      $('#order_number_validate').show();
      $('#add2order-msg').hide();
    } else {
      $('#order_number_validate').hide();
      $('#add2order-msg').show();
    }
  });

  $(document).on('click', 'button[name="confirmDeliveryOption"]', function(event){
    if ($('input[type=radio]:checked').hasClass('add2order')) {
      if ($('#added_to_order').val().length <= 0) {
        event.preventDefault();
        htmlBlock = '<div class="alert alert-danger" role="alert"><strong>Er is geen bestelling geselecteerd!</strong> Zoek eerst een nog lopende bestelling of selecteer een andere verzendmethode</div>';
        $('#desired_reference_error').html(htmlBlock);
      }
    }
  });

  // toevoegen aan order check
  // test reference failing: YS-53931, success: YS-53936, YS-53935
  $(document).on('click', '#search_order_for_shipping', function(event){
    event.preventDefault();
    const desiredReference = $('#desired_reference').val();

    if (typeof url === 'undefined') {
      var url = '/index.php?fc=module&module=addtoorder&controller=ajax&id_lang=1';
    }

    $.ajax({
      url: url,
      type: 'GET',
      data: {
        reference: desiredReference,
        method: 'fetchbyreference',
        ajax: true,
      },
    })
      .done(function(e){
        var htmlBlock = '';
        $('#order_number_validate').find('.errorsmall').remove();
        $('#desired_reference').removeClass('error-form');
        if (e.length > 0) {
          addToOrderAddress.city = e[0].address.city;
          addToOrderAddress.country = e[0].address.id_country;
          addToOrderAddress.postcode = e[0].address.postcode;
          addToOrderAddress.address1 = e[0].address.address1;
          addToOrderAddress.house_number = e[0].address.house_number;
          addToOrderAddress.house_number_extension = e[0].address.house_number_extension;
          addToOrderAddress.company = e[0].address.company;
          addToOrderAddress.firstname = e[0].address.firstname;
          addToOrderAddress.lastname = e[0].address.lastname;
          addToOrderAddress.phone = e[0].address.phone;
          htmlBlock = 'De bestelling met referentie <strong>'+desiredReference+'</strong> is nog beschikbaar voor gratis toevoegen. ' +
            'De bestelling word geleverd op postcode <br/>' +
            '<span style="font-size:16px;" class="col-6 badge badge-success">'+e[0].postcode+'</span>' +
            '<span class="info-icon-add-to-order" data-id="add_to_order_info"><i class="icon-info ml-2"></i></span>' +
            '<br/>' +
            '<div style="display:none;" class="border-bottom-0 pb-1 row" id="add_to_order_info">' +
            '<span class="col-12 text-left width-100" style="color:blue;">Vanwege de AVG regels kunnen wij u niet meer informatie verschaffen dan de postcode. Kijk daarom de postcode en uw referentie goed na voordat u deze bestelling er aan toevoegd.</span>' +
            '</div><br/>'
            + '<div class="btn-group w-100"><a id="searchOrderByReferenceAgain" class="btn btn-sm btn-primary text-white" href="#"><i class="fas fa-search"></i> Opnieuw Zoeken</a>';

          $('#order_number_validate').hide();
          $('#order_number_show_block').html(htmlBlock);
          $('#order_number_show').show();
          $('#added_to_order').val(desiredReference);
          $('.add-to-existing-order-form .add2order-allowed').removeClass('not-allowed');
          $('.add-to-existing-order-form input[type="radio"]').removeAttr('disabled').prop('checked', true);
          $('#desired_reference').addClass('ok-form');
        } else {
          htmlBlock = '<div class="alert alert-danger" role="alert"><strong>De gewenste bestelling is niet meer voor toevoegen beschikbaar!</strong> Zoek nogmaal op referentie of selecteer een andere verzendmethode</div>';
          $('#desired_reference_error').html(htmlBlock);
          $('#desired_reference').addClass('error-form');
        }

        $('#searchOrderByReferenceAgain').on('click', function(event){
          event.stopImmediatePropagation();
          $('#order_number_show').hide();
          $('#added_to_order').val(null);
          $('#order_number_show_block').html('');
          $('#order_number_validate').show();
        });

        $('.info-icon-add-to-order').on('click', function (event) {
          event.preventDefault();
          const block = $(this).attr('data-id');
          $('#'+block).toggle();
        });
      })
      .fail(function(e){
        // console.log(['error', e]);
      });
  });

  $('.showOrderTracking').on('click', function (event) {
    event.preventDefault();
    const ref = $(this).attr('data-order-reference');
    const history = JSON.parse($(this).attr('data-history'));
    $('#trackingModalLabel').text('Status informatie voor bestelling '+ref);

    if (typeof url === 'undefined') {
      var url = '/index.php?fc=module&module=koopmanorderexport&controller=ajax&id_lang=1';
    }

    $.ajax({
      url: url,
      type: 'GET',
      data: {
        reference: ref,
        method: 'orderstatus',
        ajax: true,
      },
    }).done(function(e){
      const data = JSON.parse(e);
      if (data.hasOwnProperty('error')) {
      } else {
        $('#trackingModalBarcode').text(data.barcode);

        if (data.package.weight !== '') {
          $('#trackingModalWeight').html(data.package.weight+'<sub>Kg</sub>');
        } else {
          $('#trackingModalWeight').html('');
        }

        if (data.package.length !== '' && data.package.height !== '') {
          $('#trackingModalPackageSize').html(data.package.length+'<small>cm</small> x '+data.package.height+'<small>mm</small>');
        } else {
          $('#trackingModalPackageSize').html('');
        }

        if (data.delivered.signature_name === '') {
          $('#trackingModalDeliveryTimeEstimate').text(data.scheduled_delivery_moment.planned_delivery_date+' tussen '+data.scheduled_delivery_moment.from+' - '+data.scheduled_delivery_moment.to);
          $('#trackingModalDelivered').hide();

          $('#trackingModalSignature').html('');
          $('#trackingModalDeliveredOn').text('');
        } else {
          $('#trackingModalEstimateDelivery').hide();
          $('#trackingModalDelivered').show();
          $('#trackingModalSignatureBox').show();
          $('#trackingModalSignature').html('<img src="data:image/jpeg;base64,'+data.delivered.signature+'" class="w-100 border" alt="De handtekening van de ontvanger"><br><strong class="w-100">'+data.delivered.signature_name+'</strong>');
          $('#trackingModalDeliveredOn').text(data.delivered.delivered_at+' om '+data.delivered.delivered_on);

          $('#trackingModalDeliveryTimeEstimate').text('');
        }

        const latestHistory = data.history[data.history.length - 1];
        for (var i = 0, length = data.history.length; i < length; i++) {
          // console.log([latestHistory, data.history]);

          setTrackingLabel('#trackingModalOrderReceived', 'done');

          switch (data.history[i].state_id) {
            case '1': // Wachtend op betaling
              if (latestHistory.state_id === '1') {
                setTrackingLabel('#trackingModalPaymentReceived', 'failed');
              } else {
                setTrackingLabel('#trackingModalPaymentReceived', 'done');
              }
              break;
            case '2': // Betaling aanvaard
              setTrackingLabel('#trackingModalPaymentReceived', 'done');
              break;
            case '3': // Word voorbereid
              if (latestHistory.state_id === '3') {
                setTrackingLabel('#trackingModalOrderPicked', 'active');
              } else {
                setTrackingLabel('#trackingModalOrderPicked', 'done');
              }

              break;
            case '4': // Verzonden
              if (latestHistory.state_id === '4') {
                setTrackingLabel('#trackingModalOrderTransferredToTransmission', 'active');
              } else {
                setTrackingLabel('#trackingModalOrderTransferredToTransmission', 'done');
              }

              break;
            case '5': // Afgeleverd
              setTrackingLabel('trackingModalOrderDeliverd', 'done');
              break;
            case '6': // Geannulleerd
              setTrackingLabel('', 'done');
              break;
            case '7': // Terugbetaald
              if (latestHistory.state_id === '4') {
                setTrackingLabel('', 'done');
              } else {

              }
              break;
            case '8': // Betalingsfout
              if (latestHistory.state_id === '4') {
                setTrackingLabel('', 'done');
              } else {

              }
              break;
            case '9': // Momenteel in backorder (betaald)
              if (latestHistory.state_id === '4') {
                setTrackingLabel('', 'done');
              } else {

              }
              break;
            case '10': // In afwachting van bankoverschrijving
              if (latestHistory.state_id === '4') {
                setTrackingLabel('', 'done');
              } else {

              }
              break;
            case '11': // Betaling op afstand aanvaard
              if (latestHistory.state_id === '4') {
                setTrackingLabel('', 'done');
              } else {

              }
              break;
            case '12': // Momenteel in backorder (niet betaald)
              if (latestHistory.state_id === '4') {
                setTrackingLabel('', 'done');
              } else {

              }
              break;
            case '13': // Wachtend op bevastiging (rembours)
              if (latestHistory.state_id === '4') {
                setTrackingLabel('', 'done');
              } else {

              }
              break;
            case '14': // Klaar voor verzending
              if (latestHistory.state_id === '14') {
                setTrackingLabel('#trackingModalOrderReadyForShipping', 'active');
              } else {
                setTrackingLabel('#trackingModalOrderReadyForShipping', 'done');
              }
              break;

            // /Transmission stattussen
            case '20': // Op depot in friesland
              if (latestHistory.state_id === '20') {
                setTrackingLabel('#trackingModalOrderTransferredToTransmission', 'active');
              } else {
                setTrackingLabel('#trackingModalOrderTransferredToTransmission', 'done');
              }
              break;
            case '30': // Op uitleverings depot
              if (latestHistory.state_id === '30') {
                setTrackingLabel('#trackingModalOrderArivedTransmissionDepot', 'active');
              } else {
                setTrackingLabel('#trackingModalOrderArivedTransmissionDepot', 'done');
              }
              break;
            case '188': // In uitlevering
              if (latestHistory.state_id === '188') {
                setTrackingLabel('#trackingModalOrderDeliveryOnRoute', 'active');
              } else {
                setTrackingLabel('#trackingModalOrderDeliveryOnRoute', 'done');
              }
              break;
            case '39': // Afgeleverd
              setTrackingLabel('#trackingModalOrderDeliverd', 'done');
              break;
            case '0': // Afgeleverd
              setTrackingLabel('#trackingModalOrderDeliverd', 'done');
              break;
            // Default value
            default:
              // statements_def
              break;
          }
        }
        // $('#trackingModalOrderReceived').text();
        // $('#trackingModalPaymentReceived').text();
        // $('#trackingModalOrderPicked').text();
        // $('#trackingModalOrderReadyForShipping').text();
        // $('#trackingModalOrderTransferredToTransmission').text();
        // $('#trackingModalOrderArivedTransmissionDepot').text();
        // $('#trackingModalOrderDeliveryOnRoute').text();
        // $('#trackingModalOrderDeliverd').text();
      }
      // console.log(e);
    });
  });

  function setTrackingLabel(id, className) {
    if (!$(id).hasClass(className)) {
      $(id).addClass(className);
    }
  }

  // Faq page toggle
  $('.page-cms').on('click', '.accordion .faq-button', function (event) {
    event.stopImmediatePropagation();
    // console.log($(this).data());
    const id = $(this).data('target');
    $(this).toggleClass('collapsed');
    $(id).toggle();
  });

  $('#facets .nav-link').on('click', function (event) {
    event.stopImmediatePropagation();
    const clickedBtn = $(this);
    const id = '#facet_'+clickedBtn.attr('id');
    if (clickedBtn.siblings('.dropdown-menu').length > 0) {
      if (clickedBtn.siblings('.dropdown-menu').hasClass('d-block')) {
        $('#facets .nav-item .dropdown-menu').removeClass('d-block');
      } else {
        $('#facets .nav-item .dropdown-menu').removeClass('d-block');
        clickedBtn.siblings('.dropdown-menu').addClass('d-block');
      }
      event.preventDefault();
      $('body, html').animate({
        scrollTop: $(id).offset().top - 110,
      }, 800);
    }
  });

  $('.doFilter').on('click', function (event) {
    event.preventDefault();
    const id = $(this).attr('data-filter-id');
    var searchQuery = '';

    $('.facet-list').each(function(index, masterEl){
      if (searchQuery === '') {
        searchQuery += masterEl.dataset.facetType.replace(' ', '+');
        $(masterEl).find('[type=checkbox]:checked').each(function(index, el){
          searchQuery += '-'+el.dataset.filterValue.replace(' ', '+');
        });
      } else {
        searchQuery += '/'+masterEl.dataset.facetType.replace(' ', '+');
        $(masterEl).find('[type=checkbox]:checked').each(function(index, el){
          searchQuery += '-'+el.dataset.filterValue.replace(' ', '+');
        });
      }
    });
    const match = RegExp('[?&]q=([^&]*)').exec(prestashop.urls.current_url);
    var prefix = '';

    if (match !== null) {
      if (match[0].indexOf('?') !== -1) {
        prefix = '?q=';
      } else {
        prefix = '&q=';
      }
      window.location = prestashop.urls.current_url.replace(/[?&]q=([^&]*)/, prefix + searchQuery);
    } else if (prestashop.urls.current_url.indexOf('?') > -1) {
      window.location = prestashop.urls.current_url+'&q='+searchQuery.replace(' ', '+');
    } else {
      window.location = prestashop.urls.current_url+'?q='+searchQuery.replace(' ', '+');
    }
  });
});


var showFlyimgImage = function (caller_element) {
  var element = cartBlock = null;
  element = $(caller_element).closest('.product-miniature').find('.carousel-item.active > .thumb').first();
  // console.log(caller_element);
  if (!element.length){
    element = $(caller_element).closest('.product-miniature').find('.thumb').first();
  }
  if (!element.length) element = $('.product-miniature').find('.thumb').first();


  if (!element || !element.length) return false;

  const elementOffset = element.offset().top;
  const pictureOffsetOriginal = element.hasClass('thumb') ? $(caller_element).offset() : element.offset(); // hover image feature scroll front image up so its offset is not correct
  if (!pictureOffsetOriginal) return false;

  pictureOffsetOriginal.right = $(window).innerWidth() - pictureOffsetOriginal.left - Math.floor(element.width() / 2);

  const flying_image_width = element.width();
  const flying_image_height = element.height();

  cartBlock = $('#top-header-shoppingcart-box');
  if (!cartBlock.is(':visible')) {
    cartBlock = $('#top-header-shoppingcart-mobile');
  }

  if (!cartBlock || !cartBlock.length) return false;

  const cartBlockOffset = cartBlock.offset();
  if (!cartBlockOffset) return false;
  cartBlockOffset.right = $(window).innerWidth() - cartBlockOffset.left - Math.floor(cartBlock.width() - 50);
  $('.flying_image').remove();
  // using clone one is better, new one would take time to load
  element.clone().removeClass('w-100').addClass('flying_image').on('load', function () {
    $(this).show().animate({
      width: '50px',
      height: '50px',
      opacity: 0.5,
      top: cartBlockOffset.top,
      right: cartBlockOffset.right,
    }, ((pictureOffsetOriginal.top - cartBlockOffset.top) < 1000 ? 1000 : pictureOffsetOriginal.top - cartBlockOffset.top))
      .fadeOut(70, function () {
        $(this).remove();
      });

    $('body,html').animate({
      scrollTop: cartBlockOffset.top,
    }, ((pictureOffsetOriginal.top - cartBlockOffset.top) < 1000 ? 1000 : pictureOffsetOriginal.top - cartBlockOffset.top));
  })
    .css({
      top: element.offset().top,
      right: cartBlockOffset.right - flying_image_width,
      width: flying_image_width,
      height: flying_image_height,
      display: 'none',
    })
    .appendTo($('main'));
  return true;
};


// Voeg regel toe aan winkel wagen
$(document).on('click', '#addCustomProductByEmployee', function (event) {
  event.preventDefault();

  var rowId = Math.random().toString(36).substr(2, 9);
  const cart = $(this).attr('data-cart');
  const htmlBlock = '<li class="cart-item w-100 p-2"> ' +
    '<div class="product-line-grid col-12">' +
    '<div class="row pb-1"> ' +
    '<input type="text" class="col-12 form-control" name="custom_product_label" placeholder="Titel"/> ' +
    '</div> ' +
    '<div class="row"> ' +
    '<div class="product-line-grid-left col-12 col-sm-5 col-md-5 col-lg-5"> ' +
    '<div class="row"> ' +
    '<textarea class="col-12 form-control customer_product_description" rows="5" name="custom_product_description" id="'+rowId+'custom_product_description" placeholder="Omschrijving"></textarea> ' +
    '</div></div>' +
    '<div class="product-line-grid-body col-12 col-sm-7 col-md-7 col-lg-7 text-center text-sm-left"> ' +
    '<div class="row"> <div class="col-4"> ' +
    '<input type="number" class="form-control" min="1" step="0.5" name="custom_product_total" placeholder="Aantal"/> </div>' +
    '<div class="col-4"> <div class="input-group"><div class="input-group-prepend">' +
    '<span class="input-group-text">€</span></div>' +
    '<input type="number" min="0.05" max="999999999999" step="0.05" class="form-control" name="custom_product_price" placeholder="Prijs"/></div> ' +
    '</div><div class="col-4"> <div class="btn-group float-right"> <button  data-cart="'+cart+'" class="btn btn-secondary btn-danger removeCustomProductEmployee"><i class="fas fa-times"></i></button> ' +
    '<button data-cart="'+cart+'" class="btn btn-secondary btn-success saveCustomProductEmployee" data-id="'+rowId+'"><i class="fas fa-check"></i></button> </div></div></div>' +
    '<div class="row col-4 offset-4 p-2">' +
    '    <div class="onoffswitch float-right">\n' +
    '        <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="switch_'+rowId+'" tabindex="0" checked>\n' +
    '        <label class="onoffswitch-label mb-0" for="switch_'+rowId+'">\n' +
    '            <span class="onoffswitch-inner"></span>\n' +
    '            <span class="onoffswitch-switch"></span>\n' +
    '        </label>\n' +
    '    </div></div>\n'+
    '</div><hr class="text-dark" style="opacity: 0.8"> </div></div></li>';

    var cartItems = '<ul class="cart-items list-unstyled col-12"></ul>';
    if($('.cart-overview.js-cart.row .cart-items').length === 0){
      $('.cart-overview.js-cart.row .no-items').remove();
      $('.cart-overview.js-cart.row').append(cartItems);
    }
    $('.cart-overview.js-cart.row .cart-items').append(htmlBlock);

    tinymce.suffix = '.min';
    tinymce.baseURL = window.location.origin + '/js/tiny_mce';
    tinymce.init({
      theme_url: '/js/tiny_mce/themes/silver/theme.min.js',
      theme: 'silver',
      relative_urls: true,
      remove_script_host: false,
      selector: '#'+rowId+'custom_product_description',
      branding: false,
      toolbar_mode: 'sliding',
      menubar: false,
      width : "100%",
      plugins: 'lists fullscreen',
      toolbar: 'fullscreen | bold italic underline striketrough subscript superscript | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent'
    });
});



$(document).on('click', '.removeCustomProductEmployee', function (event) {
  event.preventDefault();
  const parentLI = $(this).parents('li');
  parentLI.remove();
});
$(document).on('click', '.saveCustomProductEmployee', function (event) {
  event.preventDefault();

  var rowId = $(this).attr('data-id');
  const parentRow = $(this).parents('.product-line-grid');
  const label = parentRow.find('[name="custom_product_label"]').val();
  const qty = parentRow.find('[name="custom_product_total"]').val();
  const price = parentRow.find('[name="custom_product_price"]').val();
  const switchInput = parentRow.find('[name="onoffswitch"]').is(':checked');

  parentRow.find('.error-msg-custom-product').remove();

  if(isNaN(Number(qty)))
  {
    parentRow.prepend('<span class="text-danger row mb-1 error-msg-custom-product">Er is geen aantal ingevuld</span>')
    return;
  }

  if(isNaN(Number(price)))
  {
    parentRow.prepend('<span class="text-danger row mb-1 error-msg-custom-product">Er is geen prijs ingevuld</span>')
    return;
  }

  if(label.length == 0)
  {
    parentRow.prepend('<span class="text-danger row mb-1 error-msg-custom-product">Er is geen titel ingevuld</span>')
    return;
  }

  var description = tinymce.get(rowId+"custom_product_description").getContent();

  const url = '/index.php?fc=module&module=modernesmidthemeconfigurator&controller=ajax&id_lang=1';

  $.ajax({
    url: url,
    type: 'POST',
    data: {
      _token: prestashop.static_token,
      action: 'add_custom_product_to_cart',
      label:label,
      qty:qty,
      price:price,
      description:description,
      switchinput:switchInput
    },
  })
    .done(function(e){
      location.reload();
    })
    .fail(function(){
      // console.log('error');
    });
});


// $(document).on('submit', '.contact-form form', function(event) {
//   console.log('clicked')
//   var postalCodeInput = $('[name="postalcode"]');
//   if(postalCodeInput.val() == ""){
//     event.preventDefault();
//     postalCodeInput.addClass('is-invalid');
//   } else {
//     postalCodeInput.removeClass('is-invalid');
//   }

// });

function removeDiscount(id_cart_rule) {
  $.ajax({
    type: "POST",
    headers: {
      "cache-control": "no-cache"
    },
    url: '/index.php?fc=module&module=supercheckout&controller=supercheckout',
    async: true,
    cache: false,
    data: '&ajax=true&deleteDiscount=' + id_cart_rule,
    dataType: 'json',
    beforeSend: function() {
      $('#cart_update_warning .permanent-warning').remove();
      // $('.kb_velsof_sc_overlay').show();$('.pay-loader').show();
      $('#confirmLoader').show();
    },
    complete: function() {
      //$('.kb_velsof_sc_overlay').hide();$('.pay-loader').hide();
      $('#confirmLoader').hide();
    },
    success: function(json) {
      if (json['success'] != undefined) {
        notifyAlert(notification, json['success'], 'success');
        $('#discount_name').attr('value', '');
        loadCarriers();
      } else if (json['error'] != undefined) {
        $('#cart_update_warning').html('<div class="permanent-warning">' + json['error'] + '</div>');
      }
      $('#highlighted_cart_rules').html(json['cart_rule']);
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) {
      var error = sprintf(ajaxRequestFailedMsg, XMLHttpRequest, textStatus);
      $('#cart_update_warning').html('<div class="permanent-warning">' + error + '</div>');
      //$('.kb_velsof_sc_overlay').hide();$('.pay-loader').hide();
    }
  });
}
