<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Product out of stock'] = '';
$_LANGMAIL['Your order has been changed'] = '';
$_LANGMAIL['New order : #%d - %s'] = '{order_name} | {total_paid} | {carrier} | {payment}';
$_LANGMAIL['Stock coverage'] = '';
$_LANGMAIL['New return from order #%d - %s'] = '';
$_LANGMAIL['Product available'] = '';
$_LANGMAIL['Backup result'] = '';
$_LANGMAIL['Message from %1$s %2$s'] = '';

?>