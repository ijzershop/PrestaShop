<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Order confirmation'] = 'bestelling bevestigd';
$_LANGMAIL['Product out of stock'] = '';
$_LANGMAIL['Your order has been changed'] = '';
$_LANGMAIL['Order payment'] = '';
$_LANGMAIL['Product available'] = '';
$_LANGMAIL['New return from order #%d - %s'] = '';
$_LANGMAIL['New order : #%d - %s'] = '{order_name} | {total_paid} | {carrier} | {payment}';
$_LANGMAIL['Stock coverage'] = '';
$_LANGMAIL['Two-factor code recovery'] = '';

?>