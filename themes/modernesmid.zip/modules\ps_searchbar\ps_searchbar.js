/* global $ */
$(document).ready(function() {
  var $searchWidget = $('.search_widget');
  var $searchBox = $searchWidget.find('input[type=text]');
  var searchURL = $searchWidget.attr('data-search-controller-url');

  $.widget('prestashop.psBlockSearchAutocomplete', $.ui.autocomplete, {
    options: {
      messages: {
        noResults: "Geen producten gevonden.",
        results: function(amount) {
          return amount + (amount > 1 ? " producten zijn" : " product is") +
            " beschikbaar, gebruik ⬆/⬇ om te navigeren.";
        }
      }
    },
    close: function(event, ui) {
      if (!$("ul.ui-autocomplete").is(":visible")) {
        $("ul.ui-autocomplete").show();
      }
    },
    _renderItem: function(ul, product) {
      var searchBarWidth = $('.header-search-box:visible').width() - 20;
      return $("<li>")
        .append($("<a>")
          .append($("<table width='" + searchBarWidth + "'>")
            .append($("<td width='60px'>").html('<img src="' + product.cover.small.url + '" class="searchResultItem" width="50px" height="auto"> ').addClass("category"))
            .append($("<td style='vertical-align:middle'>").html(' ' + product.name + '<br/><small>' + product.description_short + '</small>').addClass("product"))
            .append($("<td style='width:50px;text-align:right;' width='50px'>").html(product.price).addClass("product price"))
            .append($("<td style='width:50px;text-align:right;' width='50px'>").html('<a href="' + prestashop.urls.pages.cart + '?token=' + prestashop.static_token + '" data-button-action="add-to-cart" data-product-id="' + product.id_product + '" class="btn-sm btn-success add-to-cart searchAddToCart ml-1 text-center text-white"><i class="fas fa-shopping-cart" data-product-id="' + product.id_product + '"></i></a>').addClass("product price"))
          )).appendTo(ul);
    }
  });
  $searchBox.psBlockSearchAutocomplete({
    source: function(query, response) {
      $.post(searchURL, {
          s: query.term,
          resultsPerPage: 10
        }, null, 'json')
        .then(function(resp) {
          $('form.header-search-box span.ui-helper-hidden-accessible').css('clip', 'unset');
          response(resp.products);
        })
        .fail(response);
    },
    select: function(event, ui) {

      if(typeof event.toElement !== "undefined")
      {
        if (event.toElement.tagName.toLowerCase() !== 'svg' && event.toElement.tagName.toLowerCase() !== 'path' && event.toElement.tagName.toLowerCase() !== 'a') {
          var url = ui.item.url;
          window.location.href = url;
        }
      }
      else if(typeof event.relatedTarget !== "undefined")
      {
        if(event.relatedTarget !== null)
        {
          if (event.relatedTarget.tagName.toLowerCase() !== 'svg' && event.relatedTarget.tagName.toLowerCase() !== 'path' && event.relatedTarget.tagName.toLowerCase() !== 'a') {
            var url = ui.item.url;
            window.location.href = url;
          }
        }
        else if(typeof event.currentTarget !== "undefined")
        {
          if (event.currentTarget.tagName.toLowerCase() !== 'svg' && event.currentTarget.tagName.toLowerCase() !== 'path' && event.currentTarget.tagName.toLowerCase() !== 'a') {
            var url = ui.item.url;
            window.location.href = url;
          }
        }
      } //endif
    }
  });
  // Hide searchbox at outside click
  var mouse_is_inside = false;
  $('.search_widget').hover(function() {
    mouse_is_inside = true;
  }, function() {
    mouse_is_inside = false;
  });

  $("body").mouseup(function() {
    if (!mouse_is_inside) {
      $('form.header-search-box span.ui-helper-hidden-accessible').css('clip', 'rect(0 0 0 0)');
      $('ul.ui-autocomplete').hide();
    }
  });

});
