console.log(`Font Awesome Pro 6.3.0 by @fontawesome - https://fontawesome.com
License - https://fontawesome.com/license (Commercial License)
Copyright 2023 Fonticons, Inc.
`)