export const faGoogle: IconDefinition;
export const faFacebook: IconDefinition;
export const faWhatsapp: IconDefinition;
export const faTwitter: IconDefinition;
import { IconDefinition, IconLookup, IconName, IconPrefix, IconPack } from '@fortawesome/fontawesome-common-types';
export { IconDefinition, IconLookup, IconName, IconPrefix, IconPack } from '@fortawesome/fontawesome-common-types';
export const prefix: IconPrefix;
export const fab: IconPack;