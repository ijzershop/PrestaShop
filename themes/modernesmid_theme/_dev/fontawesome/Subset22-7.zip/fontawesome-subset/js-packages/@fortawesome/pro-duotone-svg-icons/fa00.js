'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = '00';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e467';
var svgPathData = ['M352 176c0-79.5 64.5-144 144-144s144 64.5 144 144V336c0 79.5-64.5 144-144 144s-144-64.5-144-144V176zM496 96c-44.2 0-80 35.8-80 80V336c0 44.2 35.8 80 80 80s80-35.8 80-80V176c0-44.2-35.8-80-80-80z', 'M0 176C0 96.5 64.5 32 144 32s144 64.5 144 144V336c0 79.5-64.5 144-144 144S0 415.5 0 336V176zM144 96c-44.2 0-80 35.8-80 80V336c0 44.2 35.8 80 80 80s80-35.8 80-80V176c0-44.2-35.8-80-80-80z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.fa00 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;