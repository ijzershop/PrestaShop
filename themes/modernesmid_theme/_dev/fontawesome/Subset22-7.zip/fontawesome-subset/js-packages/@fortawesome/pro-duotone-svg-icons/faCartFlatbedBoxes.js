'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'cart-flatbed-boxes';
var width = 640;
var height = 512;
var aliases = ["dolly-flatbed-alt"];
var unicode = 'f475';
var svgPathData = ['M224 32c-17.7 0-32 14.3-32 32V288c0 17.7 14.3 32 32 32H352c17.7 0 32-14.3 32-32V64c0-17.7-14.3-32-32-32H224zm224 0c-17.7 0-32 14.3-32 32v64c0 17.7 14.3 32 32 32h64c17.7 0 32-14.3 32-32V64c0-17.7-14.3-32-32-32H448zM416 224v64c0 17.7 14.3 32 32 32H576c17.7 0 32-14.3 32-32V224c0-17.7-14.3-32-32-32H448c-17.7 0-32 14.3-32 32zM160 464c0 26.5 21.5 48 48 48s48-21.5 48-48c0-5.6-1-11-2.7-16H162.7c-1.8 5-2.7 10.4-2.7 16zm288 0c0 26.5 21.5 48 48 48s48-21.5 48-48c0-5.6-1-11-2.7-16H450.7c-1.8 5-2.7 10.4-2.7 16z', 'M0 32C0 14.3 14.3 0 32 0H48c44.2 0 80 35.8 80 80V368c0 8.8 7.2 16 16 16H608c17.7 0 32 14.3 32 32s-14.3 32-32 32H144c-44.2 0-80-35.8-80-80V80c0-8.8-7.2-16-16-16H32C14.3 64 0 49.7 0 32z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCartFlatbedBoxes = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;