'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'location-exclamation';
var width = 384;
var height = 512;
var aliases = ["map-marker-exclamation"];
var unicode = 'f608';
var svgPathData = ['M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 96c13.3 0 24 10.7 24 24V232c0 13.3-10.7 24-24 24s-24-10.7-24-24V120c0-13.3 10.7-24 24-24zM160 320a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z', 'M216 120c0-13.3-10.7-24-24-24s-24 10.7-24 24V232c0 13.3 10.7 24 24 24s24-10.7 24-24V120zM192 352a32 32 0 1 0 0-64 32 32 0 1 0 0 64z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faLocationExclamation = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;